import React, {useState, createRef,useRef, useEffect} from "react";
import Form from 'react-bootstrap/Form';
import Button  from "react-bootstrap/Button";
import Col  from "react-bootstrap/Col";
import { InputGroup } from "react-bootstrap/InputGroup";
import Row  from "react-bootstrap/Row";
import { Card } from 'react-bootstrap';
import ListGroup from 'react-bootstrap/ListGroup';
import Alert from 'react-bootstrap/Alert';

import FullCalendar from "@fullcalendar/react";
import dayGridPlugin from "@fullcalendar/daygrid";
import timeGridPlugin from "@fullcalendar/timegrid";
import interactionPlugin from "@fullcalendar/interaction";
import listPlugin from "@fullcalendar/list";
import { DayPicker } from "react-day-picker";
import 'react-day-picker/dist/style.css';
import parse from "date-fns/parse";

import { Calendar } from 'react-calendar'
import 'react-calendar/dist/Calendar.css';
import ptBrLocale from "@fullcalendar/core/locales/pt-br";
// import "@fullcalendar/core/main.css";
// import "@fullcalendar/daygrid/main.css";
// import "@fullcalendar/timegrid/main.css";
import clockimg from '../../../Images/clock.svg';

import CreateEvent from "./CreateEvent";
import EditEvent from "./EditEvent";
import  {getEvents}  from "../../../api/mentorApi";
import { addEvent } from "../../../api/mentorApi";
import { updateEventApi } from "../../../api/mentorApi";
import { deleteEventApi } from "../../../api/mentorApi";
import axios from "axios";
import { useQuery } from "react-query";
import moment from 'moment';

//import { useStateContext } from '../../../context/stateContext'  

// async function getEvents(){
//   const res= await fetch("https://localhost:7141/v1/mentors" + "/myEvents", {
//     method: apiMthods.get,
//     headers: {
//         "content-type": "application/json",
//         Authorization: "bearer " + token,
//     },
// })
// .then((response) => {
//     if(!response.ok){
//         const err = new Error("Error in response");
//         throw err;
//     } else{
//         console.log(JSON.stringify(response) );
//         console.log(response.json() );
//         return response.json();
//     }
// });
// return res.json();
// }

function MentorCalendarPage(){
    const [date, setDate] = useState(new Date());
    const [selectedDate, setSelectedDate] = useState(null);
    const [selectedEvent, setSelectedEvent] = useState(null);

    const [modalShow, setModalShow] = useState(false);
    const [editmodalShow, setEditModalShow] = useState(false);
    const[editevent,setEditevent] = useState({});
    const[selectedSlot,setSelectedSlot]=useState(null);
    const[isCreateEventDisplay,setIsCreateEventDisplay]=useState(false);
    const[isEditEventDisplay,setIsEditEventDisplay]=useState(false);
    const calendarRef = useRef(null);
    const [events, setEvents] = useState([]);
  //   const [events, setEvents] = useState([
  //     {
  //         id:1,
  //         title:'45 minutes session',
  //         start: parse("04/28/2023 10:00", "MM/dd/yyyy HH:mm", new Date()),
  //         end: parse("04/28/2023 10:45", "MM/dd/yyyy HH:mm", new Date()),
  //         description: 'E1 Full description',
  //         color:'#378006'
  //     },
  //     {
  //         id:2,
  //         title:'1 hour session',
  //         start: parse("04/28/2023 11:00", "MM/dd/yyyy HH:mm", new Date()),
  //         end: parse("04/28/2023 11:45", "MM/dd/yyyy HH:mm", new Date()),
  //         description: 'E2 Full description',
  //         color:'#378006'
  //     },
  //     {
  //       id:3,
  //       title:'1 hour session',
  //       start: parse("04/28/2023 01:45", "MM/dd/yyyy HH:mm", new Date()),
  //       end: parse("04/28/2023 02:45", "MM/dd/yyyy HH:mm", new Date()),
  //       description: 'E3 Full description',
  //       color:'#378006'
  //   }
  // ]);
    // let editevent={};
   // const { setModal } = useStateContext()



   useEffect(()=>{
    console.log('component mount');
    debugger; 
    //const {data,status} = useQuery("users", getEvents);
    // setEvents(getEvents());
    getEvents().then(response=>{
      debugger;debugger;
      const formattedEvents = response.map(event => ({
        ...event,
        start: moment(event.start).toISOString(),
        end: moment(event.end).toISOString(),
      }));
    
      setEvents(formattedEvents);
       
       
       });
    console.log("events-->"+events);
},[])

const handleCreateEvent = ()=>{
  debugger;
  setModalShow(true);
  setIsCreateEventDisplay(true);
}

const addNewEvent =(event)=>{
  debugger; 
  addEvent(event).then(eventresponse=>{
    debugger; 
    getEvents().then(response=>{
      debugger;debugger;
      setEvents(response);
      setModalShow(false);
       });
  });
  
  //setEvents(oldEvents=>[...oldEvents,event]);
}

const deleteEvent = (eventObj)=>{
  deleteEventApi(eventObj).then(deleteres=>{
    getEvents().then(response=>{
      debugger;debugger;
      setEvents(response);
      setEditModalShow(false);
       });
  });
  alert("delete called");
  // setEvents(events.filter(obj=>obj.title != eventObj.title))
  // setEditModalShow(false);
}

const updateEvent = (eventObj) =>{
  debugger;
  updateEventApi(eventObj).then(updateres=>{
    debugger;
    getEvents().then(response=>{
      debugger;debugger;
      setEvents(response);
      setEditModalShow(false);
       });
  });
  // setEvents(events.map((obj)=>{
  //   if((obj != undefined && eventObj!=undefined) && (obj.title==eventObj.title)){
  //     return{...obj,...eventObj}
  //   }
  //   else{
  //     return obj;
  //   }
  // }))
  // setEditModalShow(false);
}

const handleEventClick = (eventobj)=>{
  debugger; 
 
  setEditevent(eventobj);
  // editevent=eventobj;
  setIsEditEventDisplay(true);
  setEditModalShow(true);
}

const handleCalendarEventClick =(clickInfo)=>{
 
  setSelectedEvent(clickInfo.event);
  setEditevent(clickInfo.event);
  setIsEditEventDisplay(true);
  setEditModalShow(true);
}

const eventRender =(info)=>{
  info.el.eventListener('click',()=>{
    setSelectedDate(info.event.start);
  });
}

const handleDateChange=(seldate)=>{
 debugger;
  setDate(seldate);
  getEvents().then(response=>{
    debugger;debugger;
    const formattedEvents = response.map(event => ({
      ...event,
      start: moment(event.start).toISOString(),
      end: moment(event.end).toISOString(),
    }));
  
    setEvents(formattedEvents.filter((event)=>{
      debugger;
      console.log((new Date(event.start).getDate()+'/'+new Date(event.start).getMonth()+'/'+new Date(event.start).getFullYear()) == (seldate.getDate()+'/'+seldate.getMonth()+'/'+seldate.getFullYear()));
      return ((new Date(event.start).getDate()+'/'+new Date(event.start).getMonth()+'/'+new Date(event.start).getFullYear()) == (seldate.getDate()+'/'+seldate.getMonth()+'/'+seldate.getFullYear()))
    }));
     
     
     });
  const api = calendarRef.current.getApi();
  api.gotoDate(date);
  api.changeView("timeGridDay");
}

const eventFilterOnDateChange =(event,seldate)=>{
  debugger;
  console.log((new Date(event.start).getDate()+'/'+new Date(event.start).getMonth()+'/'+new Date(event.start).getFullYear()) == (seldate.getDate()+'/'+seldate.getMonth()+'/'+seldate.getFullYear()));
return ((new Date(event.start).getDate()+'/'+new Date(event.start).getMonth()+'/'+new Date(event.start).getFullYear()) == (seldate.getDate()+'/'+seldate.getMonth()+'/'+seldate.getFullYear()))
}

const handleCalendarDateClick= (clickInfo)=>{
 
  setSelectedDate(clickInfo.date);
  console.log(selectedEvent);
  setModalShow(true);
}
function getTimeFromDate(datetime) {
  return datetime.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit', hour12: false});
}
function getStingToDate(dateString) {
  const date = new Date(dateString);
  return date.toDateString();
}
 
    

    return(

        <div className="featured-section-wrap featured-section-wrap-row">
        <div className='mainPageContainer'>        
            <div className='dashboardcontainerflex'>
              <div className='dashboardcard'>
                
                  <Card>
                  <Card.Body>
                                    
                    <Card.Text> 
                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 col-xl-5" style={{paddingTop:"7px"}}>
                            <Card.Title style={{ display: 'inline-block' }}>My Calendar</Card.Title>   
                                <Form.Group  controlId="formBasicEmail">                                    
                                    <DayPicker 
                                    selectedDays={selectedDate}
                                    onDayClick={handleDateChange}
                                    className="card"/>
                                    <h4>Events</h4>
                                    <div className="eventsContainer">
                                    {events.map((item)=>
                                      (<div onClick={()=>{handleEventClick(item)}}>
                                        
                                      <article 
                                      className="card mt-3 flex w-full cursor-pointer flex-col rounded-lg border border-slate-300 p-2 transition-all hover:animate-pulse"
                                      >
                                      <p className="text-sm" style={{margin:0}}>{item.title}</p>
                                      <p className="text-xs" style={{margin:0}}>{getStingToDate(item.start)}</p>
                                      <span className="mt-3 flex flex-row items-center gap-x-2" style={{color:"#44D5E7"}}>                                     
                                          <img src={clockimg} /> {getTimeFromDate(new Date(item.start))} -  {getTimeFromDate(new Date(item.end))}                                
                                      </span>
                                      </article></div>)
                                      )
                                    }
                                    </div>
                                

                                </Form.Group>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 col-xl-7">
                              <div className="row">
                                <div className="col">
                                <label>{(date != null && date != undefined) ? date.toDateString() : ''}</label>
                                </div>
                                <div className="col">
                                <Button variant="primary" type="submit" style={{float:"right"}} onClick={handleCreateEvent} >
                                  + Create event
                                </Button>
                                </div>
                              </div>
                              <div className="row">
                                <Form.Group className="mb-3" controlId="formBasicPassword">
                              <div
                                    style={{
                                      display: "flex",
                                      alignItems: "center",
                                      justifyContent: "center",
                                      height: "100%"
                                    }}
                                  >
                                    <div
                                      style={{
                                        boxShadow: "0 1px 2px 0 rgba(0,0,0,.1)",
                                        borderTop: "4px solid #fac863",
                                        background: "#fff",
                                        height: "100%",
                                        width: "620px",
                                        marginTop: 36,
                                        paddingTop: 14
                                      }}
                                    >
                                    <FullCalendar                                      
                                    //height={500}
                                    plugins={[timeGridPlugin, interactionPlugin]}
                                    initialView="timeGridDay"
                                    duration={{days:1}}
                                    eventClick={handleCalendarEventClick}
                                    selectable={true}
                                    dateClick={handleCalendarDateClick}
                                    //select={(info)=>setSelectedSlot(info)}
                                    events={events}
                                    ref={calendarRef}
                                    //slotDuration="00:30:00"
                                    //weekends={false}
                                    selectOverlap={false}
                                    //selectConstraint={{
                                      //  start: '06:00',
                                        //end: '20:00'
                                    //}}
                                  // eventOverlap={false}
                                  // allDaySlot={false}
                                    // headerToolbar={{
                                    //     start: 'Title Mahesh',
                                    //     center: '',
                                    //     end: 'today prev, next'
                                    // }}
                                    headerToolbar={false}
                                    eventRender={eventRender}
                                  />

                                      
                                    </div>
                              </div>
                              <div>
                                {isCreateEventDisplay && 
                                <CreateEvent show={modalShow} onHide={() => {setModalShow(false); setIsCreateEventDisplay(false);alert('create closed')}} addNewEvent={addNewEvent} ></CreateEvent>
                                }
                                
                                {isEditEventDisplay && 
                                <EditEvent editevent={editevent} deleteEvent={deleteEvent} updateEvent={updateEvent} show={editmodalShow} onHide={() => {setEditModalShow(false); setIsEditEventDisplay(false);}}></EditEvent>
                                }
                              </div>

                                </Form.Group>
                                </div>
                            </div>                           
                        </div>
                    </Card.Text>
                  </Card.Body>
                </Card>
              </div>
            </div>
        </div>
        </div>
              
            );

}
export default MentorCalendarPage;