import React from 'react';
import Button from 'react-bootstrap/Button';
//import Form from 'react-bootstrap/Form';
import Alert from 'react-bootstrap/Alert';
import '../../../../node_modules/bootstrap/dist/css/bootstrap.min.css';
import { Link, useNavigate } from 'react-router-dom';
import { useState } from 'react';
import { Card, Form, Spinner } from 'react-bootstrap';
import * as Yup from "yup";
import {useQuery, useQueryClient, useMutation } from "react-query";
import { authenticateUser } from "../../../api/userAuthApi";
import { useFormik } from "formik"
import FormErrorMessage from '../../common/shared/form-error-message/FormErrorMessage';

function LoginPage() {
  const navigate = useNavigate();
  
  const queryClient = useQueryClient();
  const mutation = useMutation(authenticateUser, {
    onSuccess: (data, error, variables, context) => {     
      navigate("/dashboard");
      window.location.reload();
      //window.location.reload();
    },
  });
  const formik = useFormik({
    initialValues: {
      user_logon: "",
      password: "",
    },
    validationSchema: Yup.object({
      user_logon: Yup.string()
      .max(50,"Must be 50 characters or less.")
      .required("User ID is required."),
      password: Yup.string()
      .max(50,"Must be 50 characters or less.")
      .required("Password is required."),
    }),
    onSubmit: (values) => {
      mutation.mutate(values);
    },
  });

  // const[data,setData] = useState({'email':'','Password':''});


  // const handleChange = (e)=>{
  //   setData({...data,[e.target.name]:e.target.value});
  // }

  // const handleSubmit =()=>{    
  //   localStorage.setItem("userId",data.email);
  //   navigate("/dashboard");
  //   window.location.reload();
  // }

  return (
    <div className="row justify-content-md-center">
      <div className='col-sm-12 col-md-6'>
        <Card className='my-5'>
          <Card.Body>
            <Card.Title>Sign In</Card.Title>
            <Form onSubmit={formik.handleSubmit}>
            <Form.Group className="mb-3" controlId="formBasicEmail">
              <Form.Label>Email address</Form.Label>
              <Form.Control 
              type="email" 
              required
              placeholder="Enter email" 
              name="user_logon" 
              value={formik.values.user_logon}
              onChange={formik.handleChange} 
              onBlur={formik.handleBlur}
             
              />
              <FormErrorMessage
                fieldName="user_logon"
                formik={formik}
              ></FormErrorMessage>
              <Form.Text className="text-muted">
                We'll never share your email with anyone else.
              </Form.Text>
            </Form.Group>

            <Form.Group className="mb-3" controlId="formBasicPassword">
              <Form.Label>Password</Form.Label>
              <Form.Control 
              type="password" 
              required
              placeholder="Password" 
              name="password" 
              onChange={formik.handleChange} 
              onBlur={formik.handleBlur}
              value={formik.values.password} 
              
              />
               <FormErrorMessage
                fieldName="password"
                formik={formik}
              ></FormErrorMessage>
            </Form.Group>
            {mutation.isError && (
              <div
                className='invalid-feedback'
                style={{
                  display: "block",
                }}
                >
                  Invalid user ID or Password
                </div>
            )}
            <Form.Group className="mb-3" controlId="formBasicCheckbox">
              <Form.Check type="checkbox" label="Remember me" />
            </Form.Group>
            {mutation.isSuccess && <div>It was successful</div>}
            <Button 
            //variant="primary" 
            type="submit" 
            className='btn btn-primary'
            disabled={mutation.isLoading}
            //onClick={handleSubmit}
            >
              Submit{" "}
              {mutation.isLoading && (
                <Spinner
                  as="span"
                  animation='border'
                  size='sm'
                  role='status'
                  aria-hidden='true'
                  >
                    <span className='visually-hidden'>Loading...</span>
                  </Spinner>
              )}
            </Button>
            <Alert key='primary' variant='primary'>
              {/* <Link to="/Register"> */}
                <Alert.Link href="/Register"> Don't have an account? Register here</Alert.Link>
                {/* </Link> */}
               
              </Alert>
              
            </Form>
          </Card.Body>
        </Card>
      </div>
    </div>
   
  );
}

export default LoginPage;