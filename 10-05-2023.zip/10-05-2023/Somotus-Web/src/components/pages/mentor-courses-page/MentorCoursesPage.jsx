import React,{useState} from "react";
import Form from 'react-bootstrap/Form';
import Button  from "react-bootstrap/Button";
import Col  from "react-bootstrap/Col";
import { InputGroup } from "react-bootstrap/InputGroup";
import Row  from "react-bootstrap/Row";
import { Card } from 'react-bootstrap';
import ListGroup from 'react-bootstrap/ListGroup';
import Alert from 'react-bootstrap/Alert';
import { addCourse } from "../../../api/mentorApi";
function MentorCoursesPage(){
  const[fileSelected,setFileSelected] = useState();
  const handleCreateCourse=(event)=>{
    debugger;
    event.preventDefault();
let formData = new FormData();
formData.append("category_id",event.target.category.value);
formData.append("title",event.target.title.value);
formData.append("short_description",event.target.shortDescription.value);
formData.append("banner_image",fileSelected);
formData.append("duration",event.target.duration.value);
formData.append("display_price",event.target.displayPrice.value);
formData.append("redirect_link",event.target.redirectUrl.value);
addCourse(formData);
  }

  const handleFileChange =(e)=>{
    debugger;
    setFileSelected(e.target.files[0]);
  }
    return(

        <div className="featured-section-wrap featured-section-wrap-row">
        <div className='mainPageContainer'>        
            <div className='dashboardcontainerflex'>
              <div className='dashboardcard'>
                  <Card style={{ width: '62rem', height: '53rem' }}>
                  <Card.Body>
                    <Card.Title style={{ display: 'inline-block' }}>My Courses</Card.Title>                   
                    <Card.Text> 
                    <Form onSubmit={handleCreateCourse}>

                          <div class="row">
                            <div class="col">
                              <Form.Group className="mb-3" controlId="formBasicEmail">
                                <Form.Label>Title</Form.Label>
                                <Form.Control type="text" placeholder="Enter title" name="title"/>
                              </Form.Group>
                            </div>
                            <div class="col">
                              <Form.Group className="mb-3" controlId="formBasicPassword">
                                <Form.Label>Catgory</Form.Label>
                                <Form.Select name="category">
                                  <option value={1}>Default select</option>
                                </Form.Select>
                              </Form.Group>
                            </div>                           
                          </div>
                          <div class="row">
                            <div class="col">
                              <Form.Group className="mb-3" controlId="formBasicEmail">
                                <Form.Label>Short Description</Form.Label>
                                <Form.Control as="textarea" rows={4} placeholder="Enter Short description" name="shortDescription" />
                              </Form.Group>
                            </div>                            
                          </div>
                          <div class="row">
                            <div class="col">
                              <Form.Group className="mb-3" controlId="formBasicEmail">
                                <Form.Label>Banner Image</Form.Label>
                                <Form.Control type="file" onChange={handleFileChange} name="bannerFile" />
                              </Form.Group>
                            </div>
                             
                          </div>
                          <div class="row">
                            <div class="col">
                              <Form.Group className="mb-3" controlId="formBasicEmail">
                                <Form.Label>Duration</Form.Label>
                                <Form.Control type="text" placeholder="Enter duration" name="duration"/>
                                
                              </Form.Group>
                            </div>
                            <div class="col">
                              <Form.Group className="mb-3" controlId="formBasicPassword">
                                <Form.Label>Display Price</Form.Label>
                                <Form.Control type="text" placeholder="Enter display price" name="displayPrice"/>
                              </Form.Group>
                            </div>
                            <div class="col">
                              <Form.Group className="mb-3" controlId="formBasicPassword">
                                <Form.Label>Redirect URL</Form.Label>
                                <Form.Control type="text" placeholder="Enter redirect URL" name="redirectUrl"  />
                              </Form.Group>
                            </div>
                          </div>   
                          <div class="row">
                            <div class="col">
                                <Button variant="primary" type="submit">
                                Submit
                                </Button>
                            </div>
                          </div>                   
                        </Form>
                    </Card.Text>
                  </Card.Body>
                </Card>
              </div>
            </div>
        </div>
        </div>
              
            );

}
export default MentorCoursesPage;