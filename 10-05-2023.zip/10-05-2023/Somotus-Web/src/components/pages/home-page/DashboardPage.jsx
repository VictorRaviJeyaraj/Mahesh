import '../../../../node_modules/bootstrap/dist/css/bootstrap.min.css'
import 'bootstrap/dist/js/bootstrap.min'
import '../../../Stylesheet/dashboard.css'
import ProfileDashboardCard from '../../common/shared/profileCards/ProfileDashboardCard'
// import './images/crm.png'
import { Card } from 'react-bootstrap';
 
import Col from 'react-bootstrap/Col';
import Row from 'react-bootstrap/Row';
import { getCurrentUser } from '../../../api/userAuthApi';
import Container from 'react-bootstrap/Container';

const DashboardPage =()=>{
  const currentUser = getCurrentUser();
    return(

<div className="featured-section-wrap featured-section-wrap-row">
<div className='mainPageContainer'>
    <ProfileDashboardCard pageData={currentUser}></ProfileDashboardCard>
    <h6 className="featured-title">Dan's Home</h6>
    <div className='dashboardcontainerflex'>
      <div className='dashboardcard'>
        <Container className='dashboardCardContainer'>
          <Row>
            <Col>
            <span style={{color:"purple",fontSize:"55px"}}>8</span>
            </Col>
            <Col>
          <Card style={{ width: '18rem' }}>
          <Card.Body>
            <Card.Title>Courses</Card.Title>
            <Card.Subtitle className="mb-2 text-muted">Total number of courses</Card.Subtitle>
            <Card.Text>
            Approved
            </Card.Text>
            <span class="text-success">Approved</span>
            <span class="top-0 start-100 translate-middle p-2 bg-success border border-light rounded-circle">1</span>
            {/* <Card.Link href="#">Card Link</Card.Link>
            <Card.Link href="#">Another Link</Card.Link> */}
          </Card.Body>
        </Card>
        </Col>
        </Row>
        </Container>
      </div>
      <div className='dashboardcard'>
      <Container className='dashboardCardContainer'>
      <Row>
            <Col>
            <span style={{color:"purple",fontSize:"55px"}}>5</span>
            </Col>
            <Col>
          <Card style={{ width: '18rem' }}>
          <Card.Body>
            <Card.Title>Resourses</Card.Title>
            <Card.Subtitle className="mb-2 text-muted">Total number of resources</Card.Subtitle>
            <Card.Text class="text-danger" >
            Approved
            {/* <span class="top-0 start-100 translate-middle p-2 bg-danger border border-light rounded-circle">2</span> */}
            </Card.Text>
            
            <span class="text-danger">Pending</span>
            <span class="top-0 start-100 translate-middle p-2 bg-danger border border-light rounded-circle">2</span>
            {/* <Card.Link href="#">Card Link</Card.Link>
            <Card.Link href="#">Another Link</Card.Link> */}
          </Card.Body>
        </Card>
        </Col>
        </Row>
        </Container>
      </div>

      <div className='dashboardcard'>
      <Container className='dashboardCardContainer'>
      <Row>
            <Col>
            <span style={{color:"purple",fontSize:"55px"}}>5</span>
            </Col>
            <Col>
          <Card style={{ width: '18rem' }}>
          <Card.Body>
            <Card.Title>Leads</Card.Title>
            <Card.Subtitle className="mb-2 text-muted">Total number of leads</Card.Subtitle>
            <Card.Text>
            Approved
            </Card.Text>
            <span class="text-success">Approved</span>
            <span class="top-0 start-100 translate-middle p-2 bg-success border border-light rounded-circle">4</span>
            {/* <Card.Link href="#">Card Link</Card.Link>
            <Card.Link href="#">Another Link</Card.Link> */}
          </Card.Body>
        </Card>
        </Col>
        </Row>
        </Container>
      </div>
     
 
    </div>
   
    
</div>
  
</div>
      
    )
}
export default DashboardPage;