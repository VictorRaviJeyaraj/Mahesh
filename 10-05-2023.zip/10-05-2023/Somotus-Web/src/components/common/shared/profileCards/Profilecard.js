import ProfilePic from '../../../../Images/avatar.png';
const Profilecard = (props) =>{
     
    return(
        <div className="profilepiccard" >
            <img src={ProfilePic} className='card-img-top' alt="Card image cap" />
            <div className="card-body">
            <p className="card-text">{props.pageData.first_name} {props.pageData.last_name}</p>
            <p className="card-text">{props.pageData.user_logon}</p>
            </div>
            </div>
    )
}
export default Profilecard;