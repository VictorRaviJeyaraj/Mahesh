import './../../../../Stylesheet/leftbar.css'
import '../../../../../node_modules/bootstrap/dist/css/bootstrap.min.css'
import 'bootstrap/dist/js/bootstrap.min'
import '../../../../../node_modules/bootstrap-icons/font/bootstrap-icons.css'
import  {Link,NavLink, useLocation}  from 'react-router-dom'
import ProfilePic from '../../../../Images/avatar.png';
import ProfileCard from '../profileCards/Profilecard';
//import ProfileCard from '../../shared/profileCards/ProfileCard';

const Leftbar = (props)=>{
    const { currentUser, showMentorBoard, showAdminBoard,showCorporateBoard } = props.pageData;
    const location = useLocation();
    
    if(location.pathname === '/dashboard')
    {
        return(
            <div className="container-fluid">
                <div className='profilepicContainer'>
                        {/* <ProfileCard></ProfileCard> */}
                </div>
                <div className="card row flex-nowrap leftnav">
                    <div className="col-auto col-md-3 col-xl-2 px-sm-2 px-0">
                        
                        <div className="d-flex flex-column align-items-center align-items-sm-start px-3 pt-2 text-white min-vh-100">
                        
                            <a href="/" className="d-flex align-items-center pb-3 mb-md-0 me-md-auto text-white text-decoration-none">
                                <div><img src={ProfilePic} className='profilepic' /></div>
                            </a>
                            {showMentorBoard && (
                            <ul className="nav nav-pills flex-column mb-sm-auto mb-0 align-items-center align-items-sm-start" id="menu">
                            <li className="nav-item">
                                {/* <a href="/dashboard" className="nav-link align-middle px-0">
                                    <i className="fs-4 bi-speedometer2"></i> <span className="ms-1 d-none d-sm-inline">Dashboard</span>
                                </a> */}
                                <Link to={"/dashboard"} className="nav-link align-middle px-0">
                                <i className="fs-4 bi-speedometer2"></i> <span className="ms-1 d-none d-sm-inline">Dashboard</span>
                                </Link>
                            </li>
                            <li>
                                {/* <a href="/profile" className="nav-link px-0 align-middle">
                                    <i className="fs-4 bi-person"></i> <span className="ms-1 d-none d-sm-inline">My Profile</span> </a> */}
                                <Link to={"/profile"} className="nav-link align-middle px-0">
                                <i className="fs-4 bi-person"></i> <span className="ms-1 d-none d-sm-inline">My Profile</span>
                                </Link>
                            </li>
                            <li>
                            
                                {/* <a href="/calendar" className="nav-link px-0 align-middle">
                                    <i className="fs-4 bi-calendar"></i> <span className="ms-1 d-none d-sm-inline">Calendar</span> </a> */}
                                <Link to={"/calendar"} className="nav-link align-middle px-0">
                                <i className="fs-4 bi-calendar"></i> <span className="ms-1 d-none d-sm-inline">Calendar</span>
                                </Link>    
                            </li>
                            <li>
                                {/* <a href="/courses" className="nav-link px-0 align-middle">
                                    <i className="fs-4 bi-display"></i> <span className="ms-1 d-none d-sm-inline">Courses</span></a> */}
                                <Link to={"/courses"} className="nav-link align-middle px-0">
                                <i className="fs-4 bi-display"></i> <span className="ms-1 d-none d-sm-inline">Courses</span>
                                </Link>     
                            </li>
                            <li>
                                <a href="/resources" data-bs-toggle="collapse" className="nav-link px-0 align-middle ">
                                    <i className="fs-4 bi-database"></i> <span className="ms-1 d-none d-sm-inline">Resources</span></a>
                            </li>
                            <li>
                                <a href="#submenu3" data-bs-toggle="collapse" className="nav-link px-0 align-middle">
                                    <i className="fs-4 bi-bell"></i> <span className="ms-1 d-none d-sm-inline">Notifications</span> </a>
                            </li>
                            
                            <li>
                                <a href="#submenu3" data-bs-toggle="collapse" className="nav-link px-0 align-middle">
                                    <i className="fs-4 bi-credit-card"></i> <span className="ms-1 d-none d-sm-inline">Payment Details</span> </a>
                            </li>
                            <li>
                                <a href="#submenu3" data-bs-toggle="collapse" className="nav-link px-0 align-middle">
                                    <i className="fs-4 bi-box-arrow-right"></i> <span className="ms-1 d-none d-sm-inline">SignOut</span> </a>
                            </li>
                        </ul>
                            )}
                        </div>
                    </div>
                    
                </div>
            </div>
        );
    }
    else{
        return(
            <div className="container-fluid">
                <div className="card row flex-nowrap leftnav">
                    <ProfileCard pageData={currentUser}></ProfileCard>
                </div>
                <div className="card row flex-nowrap leftnav">
                    <div className="col-auto col-md-3 col-xl-2 px-sm-2 px-0">
                        
                        <div className="d-flex flex-column align-items-center align-items-sm-start px-3 pt-2 text-white min-vh-100">
                        
                            <a href="/" className="d-flex align-items-center pb-3 mb-md-0 me-md-auto text-white text-decoration-none">
                                <div><img src={ProfilePic} className='profilepic' /></div>
                            </a>
                            
                            {showMentorBoard && (
                            <ul className="nav nav-pills flex-column mb-sm-auto mb-0 align-items-center align-items-sm-start" id="menu">
                                <li className="nav-item">
                                    {/* <a href="/dashboard" className="nav-link align-middle px-0">
                                        <i className="fs-4 bi-speedometer2"></i> <span className="ms-1 d-none d-sm-inline">Dashboard</span>
                                    </a> */}
                                    <Link to={"/dashboard"} className="nav-link align-middle px-0">
                                    <i className="fs-4 bi-speedometer2"></i> <span className="ms-1 d-none d-sm-inline">Dashboard</span>
                                    </Link>
                                </li>
                                <li>
                                    {/* <a href="/profile" className="nav-link px-0 align-middle">
                                        <i className="fs-4 bi-person"></i> <span className="ms-1 d-none d-sm-inline">My Profile</span> </a> */}
                                    <Link to={"/profile"} className="nav-link align-middle px-0">
                                    <i className="fs-4 bi-person"></i> <span className="ms-1 d-none d-sm-inline">My Profile</span>
                                    </Link>
                                </li>
                                <li>
                                
                                    {/* <a href="/calendar" className="nav-link px-0 align-middle">
                                        <i className="fs-4 bi-calendar"></i> <span className="ms-1 d-none d-sm-inline">Calendar</span> </a> */}
                                    <Link to={"/calendar"} className="nav-link align-middle px-0">
                                    <i className="fs-4 bi-calendar"></i> <span className="ms-1 d-none d-sm-inline">Calendar</span>
                                    </Link>    
                                </li>
                                <li>
                                    {/* <a href="/courses" className="nav-link px-0 align-middle">
                                        <i className="fs-4 bi-display"></i> <span className="ms-1 d-none d-sm-inline">Courses</span></a> */}
                                    <Link to={"/courses"} className="nav-link align-middle px-0">
                                    <i className="fs-4 bi-display"></i> <span className="ms-1 d-none d-sm-inline">Courses</span>
                                    </Link>     
                                </li>
                                <li>
                                    <a href="/resources" data-bs-toggle="collapse" className="nav-link px-0 align-middle ">
                                        <i className="fs-4 bi-database"></i> <span className="ms-1 d-none d-sm-inline">Resources</span></a>
                                </li>
                                <li>
                                    <a href="#submenu3" data-bs-toggle="collapse" className="nav-link px-0 align-middle">
                                        <i className="fs-4 bi-bell"></i> <span className="ms-1 d-none d-sm-inline">Notifications</span> </a>
                                </li>
                                
                                <li>
                                    <a href="#submenu3" data-bs-toggle="collapse" className="nav-link px-0 align-middle">
                                        <i className="fs-4 bi-credit-card"></i> <span className="ms-1 d-none d-sm-inline">Payment Details</span> </a>
                                </li>
                                <li>
                                    <a href="#submenu3" data-bs-toggle="collapse" className="nav-link px-0 align-middle">
                                        <i className="fs-4 bi-box-arrow-right"></i> <span className="ms-1 d-none d-sm-inline">SignOut</span> </a>
                                </li>
                            </ul>
                            )}
                        </div>
                    </div>
                    
                </div>
            </div>
        );
    }
   
}
export default Leftbar;