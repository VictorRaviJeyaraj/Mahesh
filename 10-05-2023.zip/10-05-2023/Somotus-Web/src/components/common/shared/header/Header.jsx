import '../../../../../node_modules/bootstrap/dist/css/bootstrap.min.css'
import '../../../../../node_modules/bootstrap/dist/js/bootstrap.min.js'
import '../../../../../node_modules/bootstrap-icons/font/bootstrap-icons.css'
import topbarLogo from '../../../../Images/Somotus-Logo1-Lighter.png';
import { Link, useNavigate } from 'react-router-dom';
import Button from 'react-bootstrap/Button';

const Header =(props)=>{
  console.log(props.pageData);
  const { currentUser, showMentorBoard, showAdminBoard,showCorporateBoard } = props.pageData;
  const navigate = useNavigate();
  const handleLogout =()=>{    
    localStorage.removeItem("user");
    localStorage.removeItem("accessToken");
    localStorage.removeItem("refreshToken");
    //navigate("/login");
    //window.location.reload();
    props.pageData({
      showMentorBoard: false,
      showAdminBoard: false,
      showCorporateBoard: false,
      currentUser: undefined,
    });
  }

    return(<nav className="navbar navbar-expand-lg navbar-light topbar">
    <div className="container-fluid">
    {/* <img src={topbarLogo} classNameName="topBarLogo" /> */}
      <h2>Somotus</h2>
      <a className="navbar-brand" href="#"></a>
      <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span className="navbar-toggler-icon"></span>
      </button>
      <div className="collapse navbar-collapse" id="navbarSupportedContent">
      <div className="navbar-nav me-auto mb-2 mb-lg-0">
      {currentUser && (
        <ul className="navbar-nav me-auto mb-2 mb-lg-0">
          <li className="nav-item">
            <a className="nav-link active" aria-current="page" href="#">Courses</a>
          </li>
          <li className="nav-item">
            <a className="nav-link" href="#">Resources</a>
          </li>
           
        </ul>
      )}
      </div>
      
        <form className="d-flex">         
        {currentUser ? (
         
            <a href="/login" className="nav-link" onClick={handleLogout}>
            LogOut
          </a>
      ) : (
        // <Button variant="primary" type="submit" onClick={handleLogout}>
        // SignIn
        // </Button>
        <div className="navbar-nav ml-auto">
              <li className="nav-item">
                <Link to={"/login"} className="nav-link">
                  Login
                </Link>
              </li>

              <li className="nav-item">
                <Link to={"/register"} className="nav-link">
                  Sign Up
                </Link>
              </li>
            </div>
      )}
        </form>
      </div>
    </div>
  </nav>)
}
export default Header;
