import { apiMthods } from "./apiUtils";
import { getToken } from "./userAuthApi";

const baseUrl = "https://localhost:7141/v1/mentors";

export function getMentorDetails(){
    const token = getToken();
    return fetch(baseUrl + "/", {
        method: apiMthods.get,
        headers: {
            "content-type": "application/json",
            Authorization: "bearer " + token,
        },
    }).then((response) => {
        if(!response.ok){
            const err = new Error("Error in response");
            throw err;
        } else{
            // console.log(JSON.stringify(response) );
            // console.log(response.json() );

            return response.json();
        }
    }).then(response=>{
       
        console.log(response);
        return response;
        
    });
}

export function getEvents(){
    
    const token = getToken();
    return fetch(baseUrl + "/myEvents", {      
        method: apiMthods.get,
        headers: {
            "content-type": "application/json",
            Authorization: "bearer " + token,
        },
    }).then((response) => {
        
        if(!response.ok){
            const err = new Error("Error in response");
            throw err;
        } else{
           
            // console.log(JSON.stringify(response) );
            // console.log(response.json() );
            return response.json();
        }
     });
    //.then(response=>{
    //     debugger;
    //     return response;
    //     // console.log(response);
    // });
}

export function addEvent(payload){
     
    const token = getToken();
    return fetch(baseUrl + "/addEvent", {
        method: apiMthods.post,
        headers: {
            "content-type": "application/json",
            Authorization: "bearer " + token,
        },
        body: JSON.stringify(payload),
    }).then((response) => {
        if(!response.ok){
            const err = new Error("Error in response");
            throw err;
        } else{
            return response;
        }
    });
}

export function updateEventApi(payload){
    const token = getToken();
    return fetch(baseUrl + "/updateEvent", {
        method: apiMthods.put,
        headers: {
            "content-type": "application/json",
            Authorization: "bearer " + token,
        },
        body: JSON.stringify(payload),
    }).then((response) => {
        if(!response.ok){
            const err = new Error("Error in response");
            throw err;
        } else{
            return response;
        }
    });
}

export function deleteEventApi(payload){
    const token = getToken();
    return fetch(baseUrl + "/deleteEvent", {
        method: apiMthods.delete,
        headers: {
            "content-type": "application/json",
            Authorization: "bearer " + token,
        },
        body: JSON.stringify(payload),
    }).then((response) => {
        if(!response.ok){
            const err = new Error("Error in response");
            throw err;
        } else{
            return response;
        }
    });
}

export function updateProfile(payload){
    const token = getToken();
    return fetch(baseUrl + "/updateProfile", {
        method: apiMthods.put,
        headers: {
            "content-type": "application/json",
            Authorization: "bearer " + token,
        },
        body: JSON.stringify(payload),
    }).then((response) => {
        if(!response.ok){
            const err = new Error("Error in response");
            throw err;
        } else{
            return response.json();
        }
    });
}

export function getMasterData(payload){
    const token = getToken();
    return fetch(baseUrl + "/master-data/"+payload, {
        method: apiMthods.get,
        headers: {
            "content-type": "application/json",
            Authorization: "bearer " + token,
        },
    }).then((response) => {
        if(!response.ok){
            const err = new Error("Error in response");
            throw err;
        } else{
            return response.json();
        }
    }).then(response=>{
        return response;
    });
}

export function addCourse(payload){
    debugger;
const token = getToken();
return fetch(baseUrl + "/addCourse",{
    method:apiMthods.post,
    headers:{
        "content-type" : "multipart/form-data",
        Authorization: "bearer " + token,
    },
    body: payload,
}).then((response)=>{
    if(!response.ok){
        const err = new Error("Error in response");
        throw err;
    } else{
        return response.json();
    }
}).then(response=>{
    return response;
});
}