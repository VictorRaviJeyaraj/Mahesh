import logo from './logo.svg';
import './App.css';
import './Stylesheet/somotus.css';
import {BrowserRouter,Routes,Route,Link } from "react-router-dom";
import LoginPage from "./components/pages/login-page/LoginPage";
import RegisterPage from "./components/pages/register-page/RegisterPage";
import DashboardPage from "./components/pages/home-page/DashboardPage";
 
import logoHead from './Images/somotus-logo-white.png';
import LeftBarNav from './LeftBarNav';
import MentorDashboard from './components/common/shared/header/SubHeader';

import { QueryClient, QueryClientProvider} from "react-query";
import LoggedoutContainer from './components/common/layout/LoggedoutContainer/LoggedoutContainer';
import LoggedinContainer from './components/common/layout/LoggedinContainer/LoggedinContainer';
import { useState, Component } from 'react';
import { useAuth } from './components/authContext/authContext';

import ProfileDashboardCard from './components/common/shared/profileCards/ProfileDashboardCard'
import MentorProfilePage from "./components/pages/mentor-profile-page/MentorProfilePage";
import MentorCalendarPage from "./components/pages/mentor-calendar-page/MentorCalendarPage";
import MentorCoursesPage from "./components/pages/mentor-courses-page/MentorCoursesPage";
import Header from './components/common/shared/header/Header';
import SubHeader from './components/common/shared/header/SubHeader';
import Leftbar from './components/common/shared/leftbar/Leftbar';
import { getCurrentUser,logout } from './api/userAuthApi';
import EventBus from "./api/EventBus";

const queryClient = new QueryClient();
 
class App extends Component {
   constructor(props) {
    super(props);
    this.logOut = this.logOut.bind(this);

    this.state = {
      showMentorBoard: false,
      showAdminBoard: false,
      showCorporateBoard: false,
      currentUser: undefined,
    };
  }

  componentDidMount() {
    const user = getCurrentUser();
     
    if (user) {
      this.setState({
        currentUser: user,
        showMentorBoard: user.role.includes("Mentor"), //ROLE_MODERATOR
        showAdminBoard: user.role.includes("Admin"), //ROLE_ADMIN
        showCorporateBoard: user.role.includes("Corporate"), //ROLE_MODERATOR
      });
    }
    
    EventBus.on("logout", () => {
      this.logOut();
    });
  }
  componentWillUnmount() {
    EventBus.remove("logout");
  }

  logOut() {
    debugger;
    logout();
    this.setState({
      showModeratorBoard: false,
      showAdminBoard: false,
      showCorporateBoard: false,
      currentUser: undefined,
    });
  }

  render() {
    const { currentUser, showMentorBoard, showAdminBoard,showCorporateBoard } = this.state;
    console.log('Role Status - ' + showMentorBoard);
      //let userId= localStorage.getItem("jwt_token");
   return(
    // <div className='wrapper flext-grow-1'>
    // <QueryClientProvider client={queryClient}>
    // {currentUser ? (
    //     <LoggedinContainer/>
    // ) : (
    //   <LoggedoutContainer/>
    // )}

    // </QueryClientProvider>
    // </div>

    <div className='wrapper flext-grow-1'>
        <div className="App">
               
                <Header pageData={this.state}/> 
                <SubHeader pageData={this.state}></SubHeader>

                <div className='layoutcontainerflex'>               
                {currentUser && (
                  <div className='layoutflexitem1'>
                  <Leftbar pageData={this.state}></Leftbar>
                  </div>
                )}
                
               
                 <div className='layoutflexitem2'>
                 <QueryClientProvider client={queryClient}>
                    <Routes>
                        <Route path="/" element={<LoginPage />}></Route>
                        <Route path="/login" element={<LoginPage />}></Route>
                        <Route path="/register" element={<RegisterPage />}></Route>
                        <Route path="/dashboard" element={<DashboardPage />}></Route>
                        <Route path="/profile" element={<MentorProfilePage />}></Route>
                        <Route path="/calendar" element={<MentorCalendarPage />}></Route>
                        <Route path="/courses" element={<MentorCoursesPage />}></Route>
                    </Routes>
                    </QueryClientProvider>
                    </div>
               
                </div>
                
            </div>
    </div>
  );
  };

  

}

export default App;
