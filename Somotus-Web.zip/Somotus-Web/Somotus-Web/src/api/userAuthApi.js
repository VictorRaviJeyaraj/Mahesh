import { apiMthods } from "./apiUtils";

const baseUrl = "";

export function authenticateUser(payload){
    return fetch(baseUrl + "/login", {
        method: apiMthods.post,
        headers: { "content-type": "application/json"},
        body: JSON.stringify(payload),
    })
    .then((response) => {
        alert(JSON.stringify(response));
        if(!response.ok){
            const err = new Error("Error in response");
            throw err;
        } else{
            return response.text();
        }
    })
    .then((data) => {
        localStorage.setItem("jwt_token",data);
    });  
};

export function getToken(){
    return localStorage.getItem("jwt_token");
}