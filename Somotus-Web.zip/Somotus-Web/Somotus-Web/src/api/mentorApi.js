import { apiMthods } from "./apiUtils";
import { getToken } from "./userAuthApi";

const baseUrl = "";
export function getMentorDetails(){
    const token = getToken();
    return fetch(baseUrl + "/", {
        method: apiMthods.get,
        headers: {
            "content-type": "application/json",
            Authorization: "bearer " + token,
        },
    }).then((response) => {
        if(!response.ok){
            const err = new Error("Error in response");
            throw err;
        } else{
            return response.json();
        }
    });
}