import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import Alert from 'react-bootstrap/Alert';
import '../../../../node_modules/bootstrap/dist/css/bootstrap.min.css';
import { Link, useNavigate } from 'react-router-dom';
import { useState } from 'react';
import { Card } from 'react-bootstrap';
function LoginPage() {
  const navigate = useNavigate();
  const[data,setData] = useState({'email':'','Password':''});
  const handleChange = (e)=>{
setData({...data,[e.target.name]:e.target.value});
  }
  const handleSubmit =()=>{    
    localStorage.setItem("userId",data.email);
    navigate("/dashboard");
    window.location.reload();
  }
  return (
    <div className="row justify-content-md-center">
      <div className='col-sm-12 col-md-6'>
        <Card className='my-5'>
          <Card.Body>
            <Card.Title>Sign In</Card.Title>
            <Form>
            <Form.Group className="mb-3" controlId="formBasicEmail">
              <Form.Label>Email address</Form.Label>
              <Form.Control type="email" placeholder="Enter email" name="email" onChange={handleChange} />
              <Form.Text className="text-muted">
                We'll never share your email with anyone else.
              </Form.Text>
            </Form.Group>

            <Form.Group className="mb-3" controlId="formBasicPassword">
              <Form.Label>Password</Form.Label>
              <Form.Control type="password" placeholder="Password" name="Password" onChange={handleChange} />
            </Form.Group>
            <Form.Group className="mb-3" controlId="formBasicCheckbox">
              <Form.Check type="checkbox" label="Remember me" />
            </Form.Group>
            <Button variant="primary" type="submit" onClick={handleSubmit}>
              Login
            </Button>
            <Alert key='primary' variant='primary'>
              {/* <Link to="/Register"> */}
                <Alert.Link href="/Register"> Don't have an account? Register here</Alert.Link>
                {/* </Link> */}
               
              </Alert>
              
            </Form>
          </Card.Body>
        </Card>
      </div>
    </div>
   
  );
}

export default LoginPage;