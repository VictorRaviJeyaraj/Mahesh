import React,{useState} from "react";
import Form from 'react-bootstrap/Form';
import Button  from "react-bootstrap/Button";
import Col  from "react-bootstrap/Col";
import { InputGroup } from "react-bootstrap/InputGroup";
import Row  from "react-bootstrap/Row";
import { Card } from 'react-bootstrap';
import Alert from 'react-bootstrap/Alert';
function RegisterPage(){
    const[validated,setValidated] = useState(false);
    const[firstName,setFirstName] = useState('');
    const[lastName,setLastName] = useState('');
    const[email,setEmail] = useState('');
    const[obj,setObj]=useState(
                               {
                                 firstName:'',
                                 lastName :'',
                                 email : '',
                                 password:''
                               });
    const handleSubmit = (event) => {
        debugger;debugger;
        const form = event.currentTarget;
        if(form.checkValidity() === false){
            event.preventDefault();
            event.stopPropagation();
        }
        else{
            setValidated(true);
        alert('FirstName = '+obj.firstName+'\n LastName :'+obj.lastName+'\n email : '+obj.email+'\n password :' +obj.password);
        }
        
    };

    const onChange = (e) => {
        if (e.target.type === 'checkbox' && !e.target.checked) {
            setObj({...obj, [e.target.name]: e.target.checked});
        } else {
            setObj({...obj, [e.target.name]: e.target.value });
        }
     }
    return(
        <div className="row justify-content-md-center">
        <div className='col-sm-12 col-md-6'>
          <Card className='my-5'>
            <Card.Body>
              <Card.Title>Sign Up</Card.Title>
                        <Form noValidate validated={validated} onSubmit={handleSubmit}>
                        <Row className="mb-3">
                            <Form.Group as={Col}  controlId="validationCustom01">
                                <Form.Label>First Name</Form.Label>
                                <Form.Control
                                required
                                type='text'
                                name="firstName"
                                placeholder="First Name"
                                defaultValue=""
                                //  onChange={(event)=>{setFirstName(event.target.value)}}
                                onChange={onChange}
                                />
                                <Form.Control.Feedback>Looks Good!</Form.Control.Feedback>
                                <Form.Control.Feedback type="invalid">Please provide First Name</Form.Control.Feedback>
                            </Form.Group>
                            
                        </Row>
                        <Row className="mb-3">
                        <Form.Group as={Col}  controlId="validationCustom02">
                        <Form.Label>Last Name</Form.Label>
                            <Form.Control
                                required
                                type='text'
                                name="lastName"
                                placeholder="Last Name"
                                defaultValue=""
                                //  onChange={(event)=>{setLastName(event.target.value)}}
                                onChange={onChange}
                                />
                                <Form.Control.Feedback>Looks Good!</Form.Control.Feedback>
                                <Form.Control.Feedback type="invalid">Please provide Last Name</Form.Control.Feedback>
                                </Form.Group>
                                </Row>

                                <Row className="mb-3">
                        <Form.Group as={Col}  controlId="validationCustom03">
                        <Form.Label>Email</Form.Label>
                            <Form.Control
                                required
                                type='email'
                                name="email"
                                placeholder="Email"
                                defaultValue=""
                                //  onChange={(event)=>{setEmail(event.target.value)}}
                                onChange={onChange}
                                />
                                <Form.Control.Feedback>Looks Good!</Form.Control.Feedback>
                                <Form.Control.Feedback type="invalid">Please provide valid email</Form.Control.Feedback>
                                </Form.Group>
                                </Row>

                                <Row className="mb-3">
                        <Form.Group as={Col}  controlId="validationCustom04">
                        <Form.Label>Password</Form.Label>
                            <Form.Control
                                required
                                type='password'
                                name="password"
                                placeholder="Paswword"
                                defaultValue=""
                                onChange={onChange}
                                />
                                <Form.Control.Feedback>Looks Good!</Form.Control.Feedback>
                                <Form.Control.Feedback type="invalid">Please provide valid email</Form.Control.Feedback>
                                </Form.Group>
                                </Row>

                                <Row className="mb-3">
                        <Form.Group as={Col}  controlId="validationCustom05">
                        <Form.Label>Confirm Password</Form.Label>
                            <Form.Control
                                required
                                type='password'
                                name="confirmPassword"
                                placeholder="Confirm Paswword"
                                defaultValue=""
                                />
                                <Form.Control.Feedback>Looks Good!</Form.Control.Feedback>
                                <Form.Control.Feedback type="invalid">Please provide valid email</Form.Control.Feedback>
                                </Form.Group>
                                </Row>
                                <Button type="submit">Register</Button>
                                <Alert key='primary' variant='primary'>
                                {/* <Link to="/Register"> */}
                                    <Alert.Link href="/Login"> Already has an account? Login here</Alert.Link>
                                    {/* </Link> */}
                                
                                </Alert>
                    </Form>
              </Card.Body>
              </Card>
              </div>
              </div>
       
    )
}

export default RegisterPage;