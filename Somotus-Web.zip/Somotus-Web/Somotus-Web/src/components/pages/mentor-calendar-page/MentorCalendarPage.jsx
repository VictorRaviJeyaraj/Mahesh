import React, {useState, createRef,useRef} from "react";
import Form from 'react-bootstrap/Form';
import Button  from "react-bootstrap/Button";
import Col  from "react-bootstrap/Col";
import { InputGroup } from "react-bootstrap/InputGroup";
import Row  from "react-bootstrap/Row";
import { Card } from 'react-bootstrap';
import ListGroup from 'react-bootstrap/ListGroup';
import Alert from 'react-bootstrap/Alert';

import FullCalendar from "@fullcalendar/react";
import dayGridPlugin from "@fullcalendar/daygrid";
import timeGridPlugin from "@fullcalendar/timegrid";
import interactionPlugin from "@fullcalendar/interaction";
import listPlugin from "@fullcalendar/list";
import { DayPicker } from "react-day-picker";
import 'react-day-picker/dist/style.css';
import parse from "date-fns/parse";

import { Calendar } from 'react-calendar'
import 'react-calendar/dist/Calendar.css';
import ptBrLocale from "@fullcalendar/core/locales/pt-br";
// import "@fullcalendar/core/main.css";
// import "@fullcalendar/daygrid/main.css";
// import "@fullcalendar/timegrid/main.css";
import clockimg from '../../../Images/clock.svg';

import CreateEvent from "./CreateEvent";
import EditEvent from "./EditEvent";
 
//import { useStateContext } from '../../../context/stateContext'  

 

function MentorCalendarPage(){
    const [date, setDate] = useState(new Date());
    const [selectedDate, setSelectedDate] = useState(null);
    const [selectedEvent, setSelectedEvent] = useState(null);
    const[isCreateEventDisplayed,setIsCreateEventDisplayed] = useState(false);
    const[isEditEventDisplayed,setIsEditEventDisplayed] = useState(false);
    const [modalShow, setModalShow] = useState(false);
    const [editmodalShow, setEditModalShow] = useState(false);
    const[editevent,setEditevent] = useState({});
    const[selectedSlot,setSelectedSlot]=useState(null);
    const calendarRef = useRef(null);
    // let editevent={};
   // const { setModal } = useStateContext()
const handleCreateEvent = ()=>{
  debugger;
  setModalShow(true);
}

const addNewEvent =(event)=>{
  setEvents(oldEvents=>[...oldEvents,event]);
}

const deleteEvent = (eventObj)=>{
  alert("delete called");
  setEvents(events.filter(obj=>obj.title != eventObj.title))
  setEditModalShow(false);
}

const updateEvent = (eventObj) =>{
  debugger;
  setEvents(events.map((obj)=>{
    if((obj != undefined && eventObj!=undefined) && (obj.title==eventObj.title)){
      return{...obj,...eventObj}
    }
    else{
      return obj;
    }
  }))
  setEditModalShow(false);
}

const handleEventClick = (eventobj)=>{
  debugger;debugger;
  setEditevent(eventobj);
  // editevent=eventobj;
  setEditModalShow(true);
}

const handleCalendarEventClick =(clickInfo)=>{
  debugger;
  setSelectedEvent(clickInfo.event);
  setEditevent(clickInfo.event);
  setEditModalShow(true);
}

const eventRender =(info)=>{
  info.el.eventListener('click',()=>{
    setSelectedDate(info.event.start);
  });
}

const handleDateChange=(date)=>{
  debugger;
  setDate(date);
  const api = calendarRef.current.getApi();
  api.gotoDate(date);
  api.changeView("timeGridDay");
}
const handleCalendarDateClick= (clickInfo)=>{
  debugger;
  setSelectedDate(clickInfo.date);
  console.log(selectedEvent);
  setModalShow(true);
}
console.log('selected date=>'+selectedDate);
    const [events, setEvents] = useState([
        {
            id:1,
            title:'45 minutes session',
            start: parse("04/22/2023 10:00", "MM/dd/yyyy HH:mm", new Date()),
            end: parse("04/22/2023 10:45", "MM/dd/yyyy HH:mm", new Date()),
           // Datestring:'',
            description: 'Full description',
            color:'#378006'
        },
        {
            id:2,
            title:'1 hour session',
            start: parse("04/22/2023 10:45", "MM/dd/yyyy HH:mm", new Date()),
            end: parse("04/22/2023 11:45", "MM/dd/yyyy HH:mm", new Date()),
            //Datestring:'',
            description: 'Full description',
            color:'#378006'
        },
        {
          id:3,
          title:'1 hour session',
          start: parse("04/22/2023 01:45", "MM/dd/yyyy HH:mm", new Date()),
          end: parse("04/22/2023 02:45", "MM/dd/yyyy HH:mm", new Date()),
          //Datestring:'',
          description: 'Full description',
          color:'#378006'
      }
    ]);

    return(

        <div className="featured-section-wrap featured-section-wrap-row">
        <div className='mainPageContainer'>        
            <div className='dashboardcontainerflex'>
              <div className='dashboardcard'>
                <div class="col">
                    <label style={{ fontWeight:"bold", top:"5%",left: "54%", width: "180px", height:"40px", position: "absolute", zIndex:2}}>{(date != null && date != undefined) ? date.toDateString() : ''}</label>
                    <Button variant="primary" type="submit" onClick={handleCreateEvent} style={{ top:"4%",left: "82%", width: "133px", height:"40px", position: "absolute", zIndex:2}}>
                    + Create event
                    </Button>
                </div>
                  <Card>
                  <Card.Body>
                    <Card.Title style={{ display: 'inline-block' }}>My Calendar</Card.Title>                   
                    <Card.Text> 
                        <div class="row">
                            <div class="col">
                                <Form.Group className="mb-3" controlId="formBasicEmail">                                    
                                    <DayPicker 
                                    selectedDays={selectedDate}
                                    onDayClick={handleDateChange}
                                    className="card"/>
                                  
                                    {/* <Calendar
                                    value={date}
                                    className="flex w-full flex-col items-center rounded-lg border border-slate-300 p-4 text-xs"
                                    onClickDecade={undefined}
                                    locale="en"
                                    next2Label={null}
                                    prev2Label={null}
                                    // prevLabel={<ArrowLeft />}
                                    // nextLabel={<ArrowRight />}
                                    /> */}
                                    <h4>Events</h4>
                                    <div className="eventsContainer">
                                {
                                  events.map((eventobj)=>
                                  (<div onClick={()=>{handleEventClick(eventobj)}}>
                                    {/* <Card.Title>{eventobj.title}</Card.Title>   */}
                                  <article 
                                  className="card mt-3 flex w-full cursor-pointer flex-col rounded-lg border border-slate-300 p-2 transition-all hover:animate-pulse"
                                  >
                                  <p className="text-sm" style={{margin:0}}>{eventobj.title}</p>
                                  <p className="text-xs" style={{margin:0}}>{eventobj.Datestring}</p>
                                  <span className="mt-3 flex flex-row items-center gap-x-2" style={{color:"#44D5E7"}}>                                     
                                      <img src={clockimg} /> 10:30 - 11:30                                    
                                  </span>
                                  </article></div>)
                                  )
                                }
                                </div>
                                

                                </Form.Group>
                            </div>
                            <div class="col">
                                <Form.Group className="mb-3" controlId="formBasicPassword">
                                  

<div
      style={{
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        height: "100%"
      }}
    >
      <div
        style={{
          boxShadow: "0 1px 2px 0 rgba(0,0,0,.1)",
          borderTop: "4px solid #fac863",
          background: "#fff",
          height: "100%",
          width: "620px",
          marginTop: 36,
          paddingTop: 14
        }}
      >
          <FullCalendar                                      
                                        //height={500}
                                        plugins={[timeGridPlugin, interactionPlugin]}
                                        initialView="timeGridDay"
                                        duration={{days:1}}
                                        eventClick={handleCalendarEventClick}
                                        selectable={true}
                                        dateClick={handleCalendarDateClick}
                                        //select={(info)=>setSelectedSlot(info)}
                                        events={events}
                                        ref={calendarRef}
                                        //slotDuration="00:30:00"
                                        //weekends={false}
                                        //selectOverlap={false}
                                        //selectConstraint={{
                                          //  start: '06:00',
                                            //end: '20:00'
                                        //}}
                                       // eventOverlap={false}
                                       // allDaySlot={false}
                                        // headerToolbar={{
                                        //     start: 'Title Mahesh',
                                        //     center: '',
                                        //     end: 'today prev, next'
                                        // }}
                                        //headerToolbar={false}
                                        eventRender={eventRender}
                                    />

        
      </div>
    </div>
    <div>
      <CreateEvent show={modalShow} onHide={() => setModalShow(false)} addNewEvent={addNewEvent}></CreateEvent>
      
     <EditEvent editevent={editevent} deleteEvent={deleteEvent} updateEvent={updateEvent} show={editmodalShow} onHide={() => setEditModalShow(false)}></EditEvent>
    </div>

                                </Form.Group>
                            </div>                           
                        </div>
                    </Card.Text>
                  </Card.Body>
                </Card>
              </div>
            </div>
        </div>
        </div>
              
            );

}
export default MentorCalendarPage;