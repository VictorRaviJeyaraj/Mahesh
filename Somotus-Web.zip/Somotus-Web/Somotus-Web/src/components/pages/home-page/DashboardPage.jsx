import '../../../../node_modules/bootstrap/dist/css/bootstrap.min.css'
import 'bootstrap/dist/js/bootstrap.min'
import '../../../Stylesheet/dashboard.css'
import ProfileDashboardCard from '../../common/shared/profileCards/ProfileDashboardCard'
// import './images/crm.png'
import { Card } from 'react-bootstrap';
 
import Col from 'react-bootstrap/Col';
import Row from 'react-bootstrap/Row';
const DashboardPage =()=>{
    return(

<div className="featured-section-wrap featured-section-wrap-row">
<div className='mainPageContainer'>
    <ProfileDashboardCard></ProfileDashboardCard>
    <h6 className="featured-title">Dan's Home</h6>
    <div className='dashboardcontainerflex'>
      <div className='dashboardcard'>
          <Card style={{ width: '18rem' }}>
          <Card.Body>
            <Card.Title>Courses</Card.Title>
            <Card.Subtitle className="mb-2 text-muted">Total number of courses</Card.Subtitle>
            <Card.Text>
            Approved
            </Card.Text>
            {/* <Card.Link href="#">Card Link</Card.Link>
            <Card.Link href="#">Another Link</Card.Link> */}
          </Card.Body>
        </Card>
      </div>
      <div className='dashboardcard'>
          <Card style={{ width: '18rem' }}>
          <Card.Body>
            <Card.Title>Resourses</Card.Title>
            <Card.Subtitle className="mb-2 text-muted">Total number of resources</Card.Subtitle>
            <Card.Text>
            Approved
            </Card.Text>
            {/* <Card.Link href="#">Card Link</Card.Link>
            <Card.Link href="#">Another Link</Card.Link> */}
          </Card.Body>
        </Card>
      </div>

      <div className='dashboardcard'>
          <Card style={{ width: '18rem' }}>
          <Card.Body>
            <Card.Title>Leads</Card.Title>
            <Card.Subtitle className="mb-2 text-muted">Total number of leads</Card.Subtitle>
            <Card.Text>
            Approved
            </Card.Text>
            {/* <Card.Link href="#">Card Link</Card.Link>
            <Card.Link href="#">Another Link</Card.Link> */}
          </Card.Body>
        </Card>
      </div>
     
 
    </div>
   
    
</div>
  
</div>
      
    )
}
export default DashboardPage;