const MentorDashboard = ()=>{
    return(
    <div className="mentordashboard">
    <h3>Mentor DashBoard</h3>
    <span>Account/Personal Info</span>
    </div>
    )
}
export default MentorDashboard;