const UserManagement = () =>{
    return(
        <div><h1>User Management</h1></div>
    )
}

export default UserManagement;