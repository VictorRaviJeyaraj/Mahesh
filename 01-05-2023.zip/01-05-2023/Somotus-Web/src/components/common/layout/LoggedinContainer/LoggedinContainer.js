import React, { Component } from "react";
import { BrowserRouter, Routes, Route, withRouter } from "react-router-dom";
import Header from '../../shared/header/Header';
import Leftbar from '../../shared/leftbar/Leftbar';
import LoginPage from "../../../pages/login-page/LoginPage";
import RegisterPage from "../../../pages/register-page/RegisterPage";
import DashboardPage from "../../../pages/home-page/DashboardPage";
 

import SubHeader from '../../shared/header/SubHeader';
import ProfileDashboardCard from '../../shared/profileCards/ProfileDashboardCard'
import MentorProfilePage from "../../../pages/mentor-profile-page/MentorProfilePage";
import MentorCalendarPage from "../../../pages/mentor-calendar-page/MentorCalendarPage";
import MentorCoursesPage from "../../../pages/mentor-courses-page/MentorCoursesPage";

class LoggedinContainer extends Component {
    constructor(props){
        super(props);
        this.state = {
            pathname: window.location.pathname
        };
    }
    componentDidMount(){
        window.addEventListener('popstate', () => {
            this.setState({ pathname: window.location.pathname});
        });
    }
    render(){       
        const { pathname } = this.state;         
        return(
            <div className="App">
                <BrowserRouter>
                <Header/> 
                <SubHeader></SubHeader>

                <div className='layoutcontainerflex'>
                 <div className='layoutflexitem1'>
                    <Leftbar></Leftbar>
                 </div>
               
                 <div className='layoutflexitem2'>
                    <Routes>
                        <Route path="/" element={<LoginPage />}></Route>
                        <Route path="/login" element={<LoginPage />}></Route>
                        <Route path="/register" element={<RegisterPage />}></Route>
                        <Route path="/dashboard" element={<DashboardPage />}></Route>
                        <Route path="/profile" element={<MentorProfilePage />}></Route>
                        <Route path="/calendar" element={<MentorCalendarPage />}></Route>
                        <Route path="/courses" element={<MentorCoursesPage />}></Route>
                    </Routes>
                    
                    </div>
               
                </div>
                </BrowserRouter>
                
            </div>
        );
    }
}
 
export default  LoggedinContainer;