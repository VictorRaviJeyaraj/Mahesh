import React, { Component } from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Header from '../../shared/header/Header';
import LoginPage from "../../../pages/login-page/LoginPage";
import RegisterPage from "../../../pages/register-page/RegisterPage";
import DashboardPage from "../../../pages/home-page/DashboardPage";

class LoggedoutContainer extends Component {
    render(){

        return(
            <div className="App">
                <BrowserRouter>
                {/* <Header/>  */}
                <div className='container py-5'>
                    <Routes>
                        <Route path="/" element={<LoginPage />}></Route>
                        <Route path="/login" element={<LoginPage />}></Route>
                        <Route path="/register" element={<RegisterPage />}></Route>
                        <Route path="/dashboard" element={<DashboardPage />}></Route>
                    </Routes>
                    
                    
                </div>
                
                </BrowserRouter>
                
            </div>
        );
    }
}

export default LoggedoutContainer;