import ProfilePic from '../../../../Images/avatar.png';
const ProfileDashboardCard = () =>{
    return(
        <div className="card profilePicDashboardCard" >
            <img src={ProfilePic} className='card-img-top' alt="Card image cap" />
            <div className="card-body">
            <p className="card-text">Dan Immanuel</p>
            <p className="card-text">DanImmanuel@gmail.com</p>
            </div>
            </div>
    )
}
export default ProfileDashboardCard;