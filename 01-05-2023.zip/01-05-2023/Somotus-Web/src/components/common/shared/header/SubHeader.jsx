import { useLocation } from "react-router-dom";
const MentorDashboard = ()=>{
    const location = useLocation();
    
    if(location.pathname === '/dashboard')
    {
     
        return(
            <div className="mentordashboard">
            <h3>Mentor DashBoard</h3>
            <span>Account/Dashboard Info</span>
            </div>
            );
    }
    else if(location.pathname === '/profile')
    {
        return(
            <div className="mentordashboard">
            <h3>Mentor Profile</h3>
            <span>Account/Personal Info</span>
            </div>
            )
    }
    else if(location.pathname === '/calendar')
    {
        return(
            <div className="mentordashboard">
            <h3>Mentor Calendar</h3>
            <span>Account/Calendar Info</span>
            </div>
            )
    }
    else if(location.pathname === '/courses')
    {
        return(
            <div className="mentordashboard">
            <h3>Mentor Courses</h3>
            <span>Account/Courses Info</span>
            </div>
            )
    }
}
export default MentorDashboard;