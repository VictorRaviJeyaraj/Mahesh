import React,{useState} from "react";
import Form from 'react-bootstrap/Form';
import Button  from "react-bootstrap/Button";
import Col  from "react-bootstrap/Col";
import { InputGroup } from "react-bootstrap/InputGroup";
import Row  from "react-bootstrap/Row";
import { Card } from 'react-bootstrap';
import ListGroup from 'react-bootstrap/ListGroup';
import Alert from 'react-bootstrap/Alert';
function MentorCoursesPage(){
    return(

        <div className="featured-section-wrap featured-section-wrap-row">
        <div className='mainPageContainer'>        
            <div className='dashboardcontainerflex'>
              <div className='dashboardcard'>
                  <Card style={{ width: '62rem', height: '53rem' }}>
                  <Card.Body>
                    <Card.Title style={{ display: 'inline-block' }}>My Courses</Card.Title>                   
                    <Card.Text> 
                    <Form>

                          <div class="row">
                            <div class="col">
                              <Form.Group className="mb-3" controlId="formBasicEmail">
                                <Form.Label>Title</Form.Label>
                                <Form.Control type="text" placeholder="Enter title" name="fname"/>
                              </Form.Group>
                            </div>
                            <div class="col">
                              <Form.Group className="mb-3" controlId="formBasicPassword">
                                <Form.Label>Catgory</Form.Label>
                                <Form.Select>
                                  <option>Default select</option>
                                </Form.Select>
                              </Form.Group>
                            </div>                           
                          </div>
                          <div class="row">
                            <div class="col">
                              <Form.Group className="mb-3" controlId="formBasicEmail">
                                <Form.Label>Short Description</Form.Label>
                                <Form.Control as="textarea" rows={4} placeholder="Enter Short description" />
                              </Form.Group>
                            </div>                            
                          </div>
                          <div class="row">
                            <div class="col">
                              <Form.Group className="mb-3" controlId="formBasicEmail">
                                <Form.Label>Banner Image</Form.Label>
                                <Form.Control type="file" />
                              </Form.Group>
                            </div>
                             
                          </div>
                          <div class="row">
                            <div class="col">
                              <Form.Group className="mb-3" controlId="formBasicEmail">
                                <Form.Label>Duration</Form.Label>
                                <Form.Control type="text" placeholder="Enter duration" name="fname"/>
                                
                              </Form.Group>
                            </div>
                            <div class="col">
                              <Form.Group className="mb-3" controlId="formBasicPassword">
                                <Form.Label>Display Price</Form.Label>
                                <Form.Control type="text" placeholder="Enter display price" name="fname"/>
                              </Form.Group>
                            </div>
                            <div class="col">
                              <Form.Group className="mb-3" controlId="formBasicPassword">
                                <Form.Label>Redirect URL</Form.Label>
                                <Form.Control type="text" placeholder="Enter redirect URL" name="lname"  />
                              </Form.Group>
                            </div>
                          </div>   
                          <div class="row">
                            <div class="col">
                                <Button variant="primary" type="submit">
                                Submit
                                </Button>
                            </div>
                          </div>                   
                        </Form>
                    </Card.Text>
                  </Card.Body>
                </Card>
              </div>
            </div>
        </div>
        </div>
              
            );

}
export default MentorCoursesPage;