import React,{useEffect, useState} from "react";
import DatePicker from "react-datepicker";
import TimePicker from "react-time-picker";
import 'react-time-picker/dist/TimePicker.css';
import 'react-clock/dist/Clock.css';
import "react-datepicker/dist/react-datepicker.css";
import  Button  from "react-bootstrap/Button";
import Form from "react-bootstrap/Form";
import  {Row} from "react-bootstrap";
import {Col} from "react-bootstrap";
import Modal from 'react-bootstrap/Modal';
function EditEvent(props){
    debugger; 
    const editeventobj = props.editevent;
    const [date,setDate] = useState(new Date());
    const[title,setTitle] =useState(props.editevent.title);
    let desc;

    //alert(props.editevent.extendedProps);
    if(props.editevent.extendedProps != undefined){
       
        desc = props.editevent.extendedProps.description;
    }
    const[description,setDescription] =useState(desc);

    const [startTime, onStartTimeChange] =useState();
    const [endTime,onEndTimeChange] = useState();
    console.log(props.editevent);
    useEffect(()=>{
      
        setTitle(props.editevent.title);
        setDescription(desc);
        onStartTimeChange((props.editevent.start != null && props.editevent.start !=undefined ) ? (new Date(props.editevent.start).getHours().toString().length == 1 ? ('0' + new Date(props.editevent.start).getHours().toString()) : new Date(props.editevent.start).getHours().toString()) + ':'+ (new Date(props.editevent.start).getMinutes().toString().length == 1 ? (new Date(props.editevent.start).getMinutes().toString() + '0') : new Date(props.editevent.start).getMinutes().toString()) : '10:00');
        onEndTimeChange((props.editevent.end != null && props.editevent.end !=undefined ) ? (new Date(props.editevent.end).getHours().toString().length == 1 ? ('0'+new Date(props.editevent.end).getHours().toString()) : new Date(props.editevent.end).getHours().toString())  + ':'+ (new Date(props.editevent.end).getMinutes().length == 1 ? (new Date(props.editevent.end).getMinutes().toString() +'0') : new Date(props.editevent.end).getMinutes().toString()) : '10:00');
        //setDate(new Date(props.editevent.start));
    },[editeventobj])
    
    console.log('startTime -->'+startTime);
    console.log('endTime -->'+endTime);

    const handleCalendarClose =()=>{

    }

    const handleCalendarOpen=()=>{

    }

    const handleTypeOfChange =() =>{

    }
    const handleDeleteEvent = () =>{
        props.deleteEvent(props.editevent);
    }

    const handleUpdateEvent = () => {
        props.updateEvent(props.editevent)
    }
    
    const handleInputTextChange=(event)=>{
        debugger;
        if(event.target.name == 'title'){
            props.editevent.title=event.target.value;
            setTitle(event.target.value);
        }
        else{
            props.editevent.description=event.target.value;
            setDescription(event.target.value);
        }
    }
    return(

        <div>
<Modal
      {...props}
      size="lg"
      aria-labelledby="contained-modal-title-vcenter"
      centered
    >
      <Modal.Header closeButton>
        <Modal.Title id="contained-modal-title-vcenter">
        Update/Delete Event
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
      <Form>
            <Row className="mb-3">
                <Form.Group className="mb-3" controlId="formTitle">
                <Form.Label>Title</Form.Label>
                <Form.Control type="text" placeholder="title" value={title} onChange={handleInputTextChange} name='title'></Form.Control>
                </Form.Group>
            </Row>

            <Row className="mb-3">
                <Form.Group className="mb-3" controlId="formDescription">
                <Form.Label>Description</Form.Label>
                <Form.Control type="text" placeholder="Description" value={description} onChange={handleInputTextChange} name='description'></Form.Control>
                </Form.Group>
            </Row>

            <Row className="mb-3">
                <Form.Group className="mb-3" controlId="formDate">
                <Form.Label>Date</Form.Label>
                <DatePicker
                 selected={date}
                 onChange={(date)=>{setDate(date)}}
                 onCalendarClose={handleCalendarClose}
                 onCalendarOpen={handleCalendarOpen}
                ></DatePicker>
                </Form.Group>
            </Row>

            <Row className="mb-3">
                <Form.Group className="mb-3" controlId="formStartTime">
                <Form.Label>Start At</Form.Label>
                <TimePicker
                 onChange={onStartTimeChange}
                 value={startTime}></TimePicker>
                </Form.Group>
            </Row>

            <Row className="mb-3">
                <Form.Group className="mb-3" controlId="formEndTime">
                <Form.Label>End At</Form.Label>
                <TimePicker
                 onChange={onEndTimeChange}
                 value={endTime}></TimePicker>
                </Form.Group>
            </Row>

            {/* <Row className="mb-3">
                <Form.Group className="mb-3" controlId="formTypeOf">
                <Form.Label>Type Of</Form.Label>
                <Form.Select aria-label="Type Of" onChange={handleTypeOfChange} >
                    <option value='1'>---select type---</option>
                </Form.Select>
                </Form.Group>
            </Row> */}
            {/* <Row className="mb-3">
                <Form.Group className="mb-3" controlId="formTypeOf">
                <Button variant="primary" type="submit"> Delete </Button>
                </Form.Group>
            </Row> */}
            <Row className="mb-3">
            <Form.Group as={Col} md={2}>
            <Button variant="primary"  onClick={handleUpdateEvent}> Update </Button>
            </Form.Group>
            <Form.Group as={Col} md={2}>
            <Button variant="primary"  onClick={handleDeleteEvent}> Delete </Button>
            </Form.Group>
            </Row>
            
        </Form>
      </Modal.Body>
      {/* <Modal.Footer>
      <Row className="mb-3">
            <Form.Group as={Col}>
            <Button variant="primary" type="submit" onClick={handleUpdateEvent}> Update </Button>
            </Form.Group>
            <Form.Group as={Col}>
            <Button variant="primary" type="submit" onClick={handleDeleteEvent}> Delete </Button>
            </Form.Group>
            </Row>
      </Modal.Footer> */}
    </Modal>

        
        </div>
    )
}

export default EditEvent;