import React,{useState} from "react";
import Button  from "react-bootstrap/Button";
import Col  from "react-bootstrap/Col";
import { InputGroup } from "react-bootstrap/InputGroup";
import Row  from "react-bootstrap/Row";
 
import Alert from 'react-bootstrap/Alert';
import { Link, useNavigate } from 'react-router-dom';
import { Card, Form, Spinner } from 'react-bootstrap';
import * as Yup from "yup";
import {useQuery, useQueryClient, useMutation } from "react-query";
import { registerWithUserDetails } from "../../../api/userAuthApi";
import { useFormik } from "formik"
import FormErrorMessage from '../../common/shared/form-error-message/FormErrorMessage';

function RegisterPage(){
    const navigate = useNavigate();
    const queryClient = useQueryClient();
    const mutation = useMutation(registerWithUserDetails, {
        onSuccess: (data, error, variables, context) => {     
        navigate("/dashboard");
        //window.location.reload();
        },
    });
    const formik = useFormik({
        initialValues: {
        firstName: "",
        lastName: "",
        email: "",
        password: "",
        confirmPassword: "",
        },
        validationSchema: Yup.object({
        firstName: Yup.string()
        //.max(50,"Must be 50 characters or less.")
        .required("First Name is required."),
        lastName: Yup.string()
        .required("Last Name is required."),
        email: Yup.string()
        .required("Email is required."),
        password: Yup.string()
        .max(50,"Must be 50 characters or less.")
        .required("Password is required."),
        confirmPassword: Yup.string()
        .max(50,"Must be 50 characters or less.")
        .required("Confirm Password is required."),
        }),
        onSubmit: (values) => {
        mutation.mutate(values);
        },
    }); 
 
    return(
        <div className="row justify-content-md-center">
        <div className='col-sm-12 col-md-6'>
          <Card className='my-5'>
            <Card.Body>
              <Card.Title>Sign Up</Card.Title>
                        <Form onSubmit={formik.handleSubmit}>
                        <Row className="mb-3">
                            <Form.Group as={Col}  controlId="validationCustom01">
                                <Form.Label>First Name</Form.Label>
                                <Form.Control
                                required
                                type='text'
                                name="firstName" 
                                value={formik.values.firstName}
                                onChange={formik.handleChange} 
                                onBlur={formik.handleBlur}
                                />
                                <FormErrorMessage
                                    fieldName="firstName"
                                    formik={formik}
                                ></FormErrorMessage>
                                <Form.Control.Feedback>Looks Good!</Form.Control.Feedback>
                                <Form.Control.Feedback type="invalid">Please provide First Name</Form.Control.Feedback>
                            </Form.Group>
                            
                        </Row>
                        <Row className="mb-3">
                        <Form.Group as={Col}  controlId="validationCustom02">
                        <Form.Label>Last Name</Form.Label>
                            <Form.Control
                                required
                                type='text'
                                placeholder="Last Name"
                                name="lastName" 
                                value={formik.values.lastName}
                                onChange={formik.handleChange} 
                                onBlur={formik.handleBlur}
                                />
                                <FormErrorMessage
                                    fieldName="lastName"
                                    formik={formik}
                                ></FormErrorMessage>
                                <Form.Control.Feedback>Looks Good!</Form.Control.Feedback>
                                <Form.Control.Feedback type="invalid">Please provide Last Name</Form.Control.Feedback>
                                </Form.Group>
                                </Row>

                                <Row className="mb-3">
                        <Form.Group as={Col}  controlId="validationCustom03">
                        <Form.Label>Email</Form.Label>
                            <Form.Control
                                required
                                type='email'
                                placeholder="Email"
                                name="email" 
                                value={formik.values.email}
                                onChange={formik.handleChange} 
                                onBlur={formik.handleBlur}
                                />
                                <FormErrorMessage
                                    fieldName="email"
                                    formik={formik}
                                ></FormErrorMessage>
                                <Form.Control.Feedback>Looks Good!</Form.Control.Feedback>
                                <Form.Control.Feedback type="invalid">Please provide valid email</Form.Control.Feedback>
                                </Form.Group>
                                </Row>

                                <Row className="mb-3">
                        <Form.Group as={Col}  controlId="validationCustom04">
                        <Form.Label>Password</Form.Label>
                            <Form.Control
                                required
                                type='password'
                                placeholder="Paswword"
                                name="password" 
                                value={formik.values.password}
                                onChange={formik.handleChange} 
                                onBlur={formik.handleBlur}
                                />
                                <FormErrorMessage
                                    fieldName="password"
                                    formik={formik}
                                ></FormErrorMessage>
                                <Form.Control.Feedback>Looks Good!</Form.Control.Feedback>
                                <Form.Control.Feedback type="invalid">Please provide valid email</Form.Control.Feedback>
                                </Form.Group>
                                </Row>

                                <Row className="mb-3">
                        <Form.Group as={Col}  controlId="validationCustom05">
                        <Form.Label>Confirm Password</Form.Label>
                            <Form.Control
                                required
                                type='password'
                                name="confirmPassword"                              
                                value={formik.values.confirmPassword}
                                onChange={formik.handleChange} 
                                onBlur={formik.handleBlur}
                                />
                                <FormErrorMessage
                                    fieldName="confirmPassword"
                                    formik={formik}
                                ></FormErrorMessage>
                                <Form.Control.Feedback>Looks Good!</Form.Control.Feedback>
                                <Form.Control.Feedback type="invalid">Please provide valid email</Form.Control.Feedback>
                                </Form.Group>
                                </Row>
                                {mutation.isError && (
                                <div
                                    className='invalid-feedback'
                                    style={{
                                    display: "block",
                                    }}
                                    >
                                    Something Went Wrong
                                    </div>
                                )}
                                {mutation.isSuccess && <div>It was successful</div>}
            <Button 
            //variant="primary" 
            type="submit" 
            className='btn btn-primary'
            disabled={mutation.isLoading}
            //onClick={handleSubmit}
            >
              Submit{" "}
              {mutation.isLoading && (
                <Spinner
                  as="span"
                  animation='border'
                  size='sm'
                  role='status'
                  aria-hidden='true'
                  >
                    <span className='visually-hidden'>Loading...</span>
                  </Spinner>
              )}
            </Button>
                                <Alert key='primary' variant='primary'>
                                {/* <Link to="/Register"> */}
                                    <Alert.Link href="/Login"> Already has an account? Login here</Alert.Link>
                                    {/* </Link> */}
                                
                                </Alert>
                    </Form>
              </Card.Body>
              </Card>
              </div>
              </div>
       
    )
}

export default RegisterPage;