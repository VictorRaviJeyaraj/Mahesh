import { apiMthods } from "./apiUtils";

const baseUrl = "https://localhost:7141/v1/users";

export function authenticateUser(payload){    
    debugger;debugger;
    return fetch(baseUrl + "/login", {
        method: apiMthods.post,
        headers: { "content-type": "application/json"},
        body: JSON.stringify(payload),
    })
    .then((response) => {
        //alert(JSON.stringify(response));
        if(!response.ok){
            const err = new Error("Error in response");
            throw err;
        } else{
            return response.json(); //response.text();
        }
    })
    .then((data) => {
       
        localStorage.setItem("jwt_token",data.access_token);
    });  
};

export function registerWithUserDetails(payload){    
    return fetch(baseUrl + "/registerWithUserDetails", {
        method: apiMthods.post,
        headers: { "content-type": "application/json"},
        body: JSON.stringify(payload),
    })
    .then((response) => {
        //alert(JSON.stringify(response));
        if(!response.ok){
            const err = new Error("Error in response");
            throw err;
        } else{
            return response.json(); //response.text();
        }
    })
    .then((data) => {
       
        localStorage.setItem("jwt_token",data.access_token);
    });  
};

export function getToken(){
    return localStorage.getItem("jwt_token");
}
export function isAuthenticated(){
    let jwt_token= localStorage.getItem("jwt_token");
    if(jwt_token){ return true;} else {return false;}

}