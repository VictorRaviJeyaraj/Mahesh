export const apiMthods = {
    get: "GET",
    post: "POST",
    put: "PUT",
    delete: "DELETE",
};