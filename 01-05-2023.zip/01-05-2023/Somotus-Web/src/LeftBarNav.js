import  {Link,NavLink}  from 'react-router-dom'

const LeftBarNav =()=>{
    return(<div>
        <NavLink to="/Admin">Admin</NavLink>
    </div>)
}

export default LeftBarNav;