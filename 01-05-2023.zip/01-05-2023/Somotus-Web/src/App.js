import logo from './logo.svg';
import './App.css';
import './Stylesheet/somotus.css';
import {BrowserRouter,Routes,Route } from "react-router-dom";
import Login from './components/pages/login-page/LoginPage';
import Register from './components/pages/register-page/RegisterPage';
import Leftbar from './components/common/shared/leftbar/Leftbar';
import Dashboard from './components/pages/home-page/DashboardPage';
import logoHead from './Images/somotus-logo-white.png';
import LeftBarNav from './LeftBarNav';
import MentorDashboard from './components/common/shared/header/SubHeader';

import { QueryClient, QueryClientProvider} from "react-query";
import LoggedoutContainer from './components/common/layout/LoggedoutContainer/LoggedoutContainer';
import LoggedinContainer from './components/common/layout/LoggedinContainer/LoggedinContainer';
import { useState } from 'react';
import { useAuth } from './components/authContext/authContext';

const queryClient = new QueryClient();

function DynamicLoader(){
  let userId= localStorage.getItem("jwt_token");
  const [currentStatus, setCurrntStatus] = useState(userId)
  function loadComponent(){
    if(!userId){
      return  <LoggedoutContainer/>;
    }
    else{
      return  <LoggedinContainer/>;
    }
   }
   return (
    <div>
         {loadComponent()}
    </div>
   
   );
}
function App() {
   let userId= localStorage.getItem("jwt_token");
   console.log(userId);
   
 
   return(
    <div className='wrapper flext-grow-1'>
    <QueryClientProvider client={queryClient}>
        <DynamicLoader />
    </QueryClientProvider>
    </div>
  );
  

}

export default App;
