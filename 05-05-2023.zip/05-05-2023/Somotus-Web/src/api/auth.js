import { createContext, useContext, useState } from "react";

const AuthContext = createContext();

function AuthProvider({ children }) {
    const [user, setUser] = useState(null);
    const [accessToken, setAccessToken] = useState(null);
    const [refreshToken, setRefreshToken] = useState(null);

    function login(userData){
        setUser(userData);
    }
    function logout(userData){
        setUser(null);
    }
    function getAccessToken(userData){

    }
    const value = {
        isAuthenticated: !!user,
        user,
        accessToken,
        refreshToken,
        login,
        logout,
        getAccessToken,
    };
    return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;


}
function useAuth(){
    const context = useContext(AuthContext);
    if(!context){
        throw new Error('useAuth must be used within an authProvidr');

    }
    return context;
}

export {AuthProvider, useAuth};