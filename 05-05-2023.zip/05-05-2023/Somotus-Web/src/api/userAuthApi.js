import { apiMthods } from "./apiUtils";

const baseUrl = "https://localhost:7141/v1/users";

export function authenticateUser(payload){    
    debugger;
    return fetch(baseUrl + "/login", {
        method: apiMthods.post,
        headers: { "content-type": "application/json"},
        body: JSON.stringify(payload),
    })
    .then((response) => {        
        if(!response.ok){
            const err = new Error("Error in response");
            throw err;
        } else{
            return response.json(); //response.text();
        }
    })
    .then((data) => {
        if (data.access_token) {
            localStorage.setItem("user", JSON.stringify(data));
          }
        localStorage.setItem("accessToken",data.access_token);
        localStorage.setItem("refreshToken",data.refresh_token);
    });  
};
export function logout() {
    localStorage.removeItem("user");
    localStorage.removeItem("accessToken");
    localStorage.removeItem("refreshToken");
  };

export function getCurrentUser() {
    debugger;debugger;
    return JSON.parse(localStorage.getItem('user'));
  };

export function registerWithUserDetails(payload){    
    return fetch(baseUrl + "/registerWithUserDetails", {
        method: apiMthods.post,
        headers: { "content-type": "application/json"},
        body: JSON.stringify(payload),
    })
    .then((response) => {
        //alert(JSON.stringify(response));
        if(!response.ok){
            const err = new Error("Error in response");
            throw err;
        } else{
            return response.json(); //response.text();
        }
    })
    .then((data) => {
       
        localStorage.setItem("jwt_token",data.access_token);
    });  
};

export function getToken(){
    return localStorage.getItem("accessToken");
}
export function isAuthenticated(){
    let jwt_token= localStorage.getItem("jwt_token");
    if(jwt_token){ return true;} else {return false;}

}