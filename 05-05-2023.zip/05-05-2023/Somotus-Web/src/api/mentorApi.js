import { apiMthods } from "./apiUtils";
import { getToken } from "./userAuthApi";

const baseUrl = "https://localhost:7141/v1/mentors";

export function getMentorDetails(){
    const token = getToken();
    return fetch(baseUrl + "/", {
        method: apiMthods.get,
        headers: {
            "content-type": "application/json",
            Authorization: "bearer " + token,
        },
    }).then((response) => {
        if(!response.ok){
            const err = new Error("Error in response");
            throw err;
        } else{
            // console.log(JSON.stringify(response) );
            // console.log(response.json() );

            return response.json();
        }
    }).then(response=>{
        debugger;
        console.log(response);
        return response;
        
    });
}

export function getEvents(){
    debugger;debugger;
    const token = getToken();
    return fetch(baseUrl + "/myEvents", {      
        method: apiMthods.get,
        headers: {
            "content-type": "application/json",
            Authorization: "bearer " + token,
        },
    }).then((response) => {
        debugger;
        if(!response.ok){
            const err = new Error("Error in response");
            throw err;
        } else{
            debugger;
            // console.log(JSON.stringify(response) );
            // console.log(response.json() );
            return response.json();
        }
     });
    //.then(response=>{
    //     debugger;
    //     return response;
    //     // console.log(response);
    // });
}

export function addEvent(payload){
    debugger;debugger;
    const token = getToken();
    return fetch(baseUrl + "/addEvent", {
        method: apiMthods.post,
        headers: {
            "content-type": "application/json",
            Authorization: "bearer " + token,
        },
        body: JSON.stringify(payload),
    }).then((response) => {
        if(!response.ok){
            const err = new Error("Error in response");
            throw err;
        } else{
            return response;
        }
    });
}

export function updateEventApi(payload){
    const token = getToken();
    return fetch(baseUrl + "/updateEvent", {
        method: apiMthods.put,
        headers: {
            "content-type": "application/json",
            Authorization: "bearer " + token,
        },
        body: JSON.stringify(payload),
    }).then((response) => {
        if(!response.ok){
            const err = new Error("Error in response");
            throw err;
        } else{
            return response;
        }
    });
}

export function deleteEventApi(payload){
    const token = getToken();
    return fetch(baseUrl + "/deleteEvent", {
        method: apiMthods.delete,
        headers: {
            "content-type": "application/json",
            Authorization: "bearer " + token,
        },
        body: JSON.stringify(payload),
    }).then((response) => {
        if(!response.ok){
            const err = new Error("Error in response");
            throw err;
        } else{
            return response;
        }
    });
}

export function updateProfile(payload){
    const token = getToken();
    return fetch(baseUrl + "/updateProfile", {
        method: apiMthods.put,
        headers: {
            "content-type": "application/json",
            Authorization: "bearer " + token,
        },
        body: JSON.stringify(payload),
    }).then((response) => {
        if(!response.ok){
            const err = new Error("Error in response");
            throw err;
        } else{
            return response.json();
        }
    });
}