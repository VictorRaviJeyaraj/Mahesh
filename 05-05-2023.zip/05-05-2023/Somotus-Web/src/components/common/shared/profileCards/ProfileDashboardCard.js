import ProfilePic from '../../../../Images/avatar.png';
const ProfileDashboardCard = (props) =>{
    return(
        <div className="card profilePicDashboardCard" >
            <img src={ProfilePic} className='card-img-top' alt="Card image cap" />
            <div className="card-body">
            <p className="card-text">{props.pageData.first_name} {props.pageData.last_name}</p>
            <p className="card-text">{props.pageData.user_logon}</p>
            </div>
            </div>
    )
}
export default ProfileDashboardCard;