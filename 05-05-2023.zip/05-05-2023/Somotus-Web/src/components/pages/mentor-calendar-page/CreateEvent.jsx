import React,{useEffect, useState} from "react";
import DatePicker from "react-datepicker";
import TimePicker from "react-time-picker";
import 'react-time-picker/dist/TimePicker.css';
import 'react-clock/dist/Clock.css';
import "react-datepicker/dist/react-datepicker.css";
import  Button  from "react-bootstrap/Button";
import Form from "react-bootstrap/Form";
import  {Row,Col} from "react-bootstrap";
// import Col from "react-bootstrap";
import Modal from 'react-bootstrap/Modal';
import parse from "date-fns/parse";

function CreateEvent(props){
    debugger; 
    let endDate= new Date();
    endDate.setMinutes(endDate.getMinutes()+30);
    const [date,setDate] = useState(new Date());
    const [startTime, onStartTimeChange] =useState( (new Date().getHours().toString().length == 1 ? ('0' + new Date().getHours().toString()) : new Date().getHours().toString()) + ':'+ (new Date().getMinutes().toString().length == 1 ? (new Date().getMinutes().toString() + '0') : new Date().getMinutes().toString()) );
    const [endTime,onEndTimeChange] = useState(endDate.getHours().toString()+':'+endDate.getMinutes().toString());
   
    useEffect(()=>{
        alert("useeffect");
        onStartTimeChange((new Date().getHours().toString().length == 1 ? ('0' + new Date().getHours().toString()) : new Date().getHours().toString()) + ':'+ (new Date().getMinutes().toString().length == 1 ? (new Date().getMinutes().toString() + '0') : new Date().getMinutes().toString()) );
        onEndTimeChange(endDate.getHours().toString()+':'+endDate.getMinutes().toString());
    },[])
   
    const handleCalendarClose =()=>{

    }

    const handleCalendarOpen=()=>{

    }

    const handleTypeOfChange =() =>{

    }

    const handleCreateNewEvent =(event)=>{
     debugger;debugger;
     let eventObj={};
     event.preventDefault();
     eventObj.title=event.target.title.value;
     eventObj.start=parse(event.target.elements.date.value + ' '+ event.target.elements.startTime.value, "MM/dd/yyyy HH:mm",new Date());
     eventObj.end=parse(event.target.elements.date.value + ' '+ event.target.elements.endTime.value, "MM/dd/yyyy HH:mm",new Date());
     eventObj.description=event.target.elements.description.value;
     eventObj.color='#378006';
     //eventObj.Datestring = new Date(event.target.elements.date.value + ' '+ event.target.elements.endTime.value).toLocaleDateString([],{ year: 'numeric', month: 'long', day: 'numeric' });
     props.addNewEvent(eventObj);
     //props.onHide();

     //console.log(event.target.title.value);
    }
    return(
        <div>
      

         <Modal
      {...props}
      size="lg"
      aria-labelledby="contained-modal-title-vcenter"
      centered
    >
      <Modal.Header closeButton>
        <Modal.Title id="contained-modal-title-vcenter">
        Create Event
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
      <Form onSubmit={handleCreateNewEvent}>
            <Row className="mb-3">
                <Form.Group className="mb-3" controlId="formTitle">
                <Form.Label>Title</Form.Label>
                <Form.Control type="text" placeholder="title" name="title"></Form.Control>
                </Form.Group>
            </Row>

            <Row className="mb-3">
                <Form.Group className="mb-3" controlId="formDescription">
                <Form.Label>Description</Form.Label>
                <Form.Control type="text" placeholder="Description" name="description"></Form.Control>
                </Form.Group>
            </Row>

            <Row className="mb-3">
                <Form.Group className="mb-3" controlId="formDate">
                <Form.Label>Date</Form.Label>
                <DatePicker
                 selected={date}
                 onChange={(date)=>{setDate(date)}}
                 onCalendarClose={handleCalendarClose}
                 onCalendarOpen={handleCalendarOpen}
                 name="date"
                ></DatePicker>
                </Form.Group>
            </Row>

            <Row className="mb-3">
                <Form.Group className="mb-3" controlId="formStartTime">
                <Form.Label>Start At</Form.Label>
                <TimePicker
                 onChange={onStartTimeChange}
                 value={startTime}
                 name="startTime"></TimePicker>
                </Form.Group>
            </Row>

            <Row className="mb-3">
                <Form.Group className="mb-3" controlId="formEndTime">
                <Form.Label>End At</Form.Label>
                <TimePicker
                 onChange={onEndTimeChange}
                 value={endTime}
                 name="endTime"></TimePicker>
                </Form.Group>
            </Row>

            {/* <Row className="mb-3">
                <Form.Group className="mb-3" controlId="formTypeOf">
                <Form.Label>Type Of</Form.Label>
                <Form.Select aria-label="Type Of" onChange={handleTypeOfChange} name="typeOf">
                    <option value='1'>---select type---</option>
                </Form.Select>
                </Form.Group>
            </Row> */}
            <Row className="mb-3">
                <Form.Group as={Col} className="mb-3" md={3}>
                <Button variant="primary" type="submit"> Create Event </Button>
                </Form.Group>
            </Row>
            {/* <Button variant="primary" type="submit"> Create Event </Button> */}
            </Form>
      </Modal.Body>
      {/* <Modal.Footer>
        <Button onClick={props.onHide}>Close</Button>
      </Modal.Footer> */}
    </Modal>
    

        </div>
    )
}

export default CreateEvent;