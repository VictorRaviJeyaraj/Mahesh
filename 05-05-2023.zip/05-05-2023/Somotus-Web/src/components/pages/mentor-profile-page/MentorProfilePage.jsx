import React,{useEffect, useState} from "react";
import Form from 'react-bootstrap/Form';
import Button  from "react-bootstrap/Button";
import Col  from "react-bootstrap/Col";
import { InputGroup } from "react-bootstrap/InputGroup";
import Row  from "react-bootstrap/Row";
import { Card } from 'react-bootstrap';
import ListGroup from 'react-bootstrap/ListGroup';
import Alert from 'react-bootstrap/Alert';
import Select from 'react-select';
import { getMentorDetails } from "../../../api/mentorApi";

// const skillsOptions = [
//   { value: 'Microsoft', label: 'Microsoft' },
//   { value: 'Java', label: 'Java' },
//   { value: 'C#', label: 'C#' }
// ]
// const languageOptions = [
//   { value: 'Kannada', label: 'Kannada' },
//   { value: 'English', label: 'English' },
//   { value: 'Hindi', label: 'Hindi' }
// ]

function MentorProfilePage(){
  debugger;
const[mentorDetails,setMentorDetails] = useState({});
const[skillsOptions,setSkillsOptions] = useState([]);
const[languageOptions,setLanguageOptions] = useState([]);
useEffect(()=>{
getMentorDetails().then(response=>{
  debugger;
  setMentorDetails(response);
  setSkillsOptions(response.skills);
  setLanguageOptions(response.languages);
  console.log(response);
})
  
},[])

    return(

        <div className="featured-section-wrap featured-section-wrap-row">
        <div className='mainPageContainer'>        
            <div className='dashboardcontainerflex'>
              <div className='dashboardcard'>
                  <Card style={{ width: '62rem', height: '53rem' }}>
                  <Card.Body>
                    <Card.Title style={{ display: 'inline-block' }}>My Profile</Card.Title>                   
                    <Card.Text>
                    <ListGroup variant="flush">
                      <ListGroup.Item> 
                      <Card.Subtitle>Personal Details</Card.Subtitle>
                        <Form>
                          <div class="row">
                            <div class="col">
                              <Form.Group className="mb-3" controlId="formBasicEmail">
                                <Form.Label>First Name</Form.Label>
                                <Form.Control type="text" placeholder="Enter first name" name="fname" value={mentorDetails.first_name}/>
                                {/* <Form.Text className="text-muted">
                                  We'll never share your email with anyone else.
                                </Form.Text> */}
                              </Form.Group>
                            </div>
                            <div class="col">
                              <Form.Group className="mb-3" controlId="formBasicPassword">
                                <Form.Label>Middle Name</Form.Label>
                                <Form.Control type="text" placeholder="Middle name" name="mname" value={mentorDetails.middle_name}  />
                              </Form.Group>
                            </div>
                            <div class="col">
                              <Form.Group className="mb-3" controlId="formBasicPassword">
                                <Form.Label>Last Name</Form.Label>
                                <Form.Control type="text" placeholder="Last name" name="lname" value={mentorDetails.last_name} />
                              </Form.Group>
                            </div>
                          </div>
                          <div class="row">
                            <div class="col">
                              <Form.Group className="mb-3" controlId="formBasicEmail">
                                <Form.Label>Email address</Form.Label>
                                <Form.Control type="email" placeholder="Enter email" name="email" value={mentorDetails.email_address}   />
                                <Form.Text className="text-muted">
                                  We'll never share your email with anyone else.
                                </Form.Text>
                              </Form.Group>
                            </div>
                            <div class="col">
                              <Form.Group className="mb-3" controlId="formBasicPassword">
                                <Form.Label>Phone Number</Form.Label>
                                <Form.Control type="text" placeholder="Phone number" name="phonenumber" value={mentorDetails.mobile_number} />
                              </Form.Group>
                            </div>
                          </div>
                          <div class="row">
                            <div class="col">
                              <Form.Group className="mb-3" controlId="formBasicEmail">
                                <Form.Label>Address</Form.Label>
                                <Form.Control as="textarea" rows={2} placeholder="Enter address"
                                value={mentorDetails.addresses.address1 + ' ' + mentorDetails.addresses.address2 + ' ' + mentorDetails.addresses.address3 + ' ' + mentorDetails.addresses.state +' '+mentorDetails.addresses.postal_code}
                                 />
                              </Form.Group>
                            </div>
                            <div class="col">
                            <Form.Group className="mb-3" controlId="formBasicEmail">
                                <Form.Label>Address2 (Optional)</Form.Label>
                                <Form.Control as="textarea" rows={2} placeholder="Enter address" />
                              </Form.Group>
                            </div>
                          </div>
                          <div class="row">
                            <div class="col">
                              <Form.Group className="mb-3" controlId="formBasicEmail">
                                <Form.Label>Country</Form.Label>
                                <Form.Select value={mentorDetails.addresses.country}>
                                  <option>Default select</option>
                                  <option value={mentorDetails.addresses.country}>{mentorDetails.addresses.country}</option>
                                </Form.Select>
                                
                              </Form.Group>
                            </div>
                            <div class="col">
                              <Form.Group className="mb-3" controlId="formBasicPassword">
                                <Form.Label>State</Form.Label>
                                <Form.Select value={mentorDetails.addresses.state}>
                                  <option>Default select</option>
                                  <option value={mentorDetails.addresses.state}>{mentorDetails.addresses.state}</option>
                                </Form.Select>
                              </Form.Group>
                            </div>
                            <div class="col">
                              <Form.Group className="mb-3" controlId="formBasicPassword">
                                <Form.Label>Postal Code</Form.Label>
                                <Form.Control type="text" placeholder="Last name" name="lname" value={mentorDetails.addresses.postal_code}  />
                              </Form.Group>
                            </div>
                          </div>                      
                        </Form>
                      </ListGroup.Item>
                      <ListGroup.Item> 
                      <Card.Subtitle>Mentorship Details</Card.Subtitle>
                        <Form>
                        <div class="row">
                            <div class="col">
                              <Form.Group className="mb-3" controlId="formBasicEmail">
                                <Form.Label>Short Biography</Form.Label>
                                <Form.Control as="textarea" rows={4} placeholder="Enter Short biography" value={mentorDetails.short_biography} />
                              </Form.Group>
                            </div> 
                          </div>
                          <div class="row">
                            <div class="col">
                              <Form.Group className="mb-3" controlId="formBasicEmail">
                                <Form.Label>Skills</Form.Label>                                
                                <Select  isMulti options={skillsOptions} />
                              </Form.Group>
                            </div>
                            <div class="col">
                              <Form.Group className="mb-3" controlId="formBasicPassword">
                                <Form.Label>Language</Form.Label>
                                <Select  isMulti options={languageOptions} />
                              </Form.Group>
                            </div>                           
                          </div> 
                          <div class="row">                            
                            <div class="col">
                              <Form.Group className="mb-3" controlId="formBasicPassword">
                                <Form.Label>Price Range</Form.Label>
                                <Form.Control type="text" placeholder="Price range" name="lname"  value={mentorDetails.price_range}  />
                              </Form.Group>
                            </div>
                            <div class="col">
                              <Form.Group className="mb-3" controlId="formBasicPassword">
                                <Form.Label>Total exp.</Form.Label>
                                <Form.Control type="text" placeholder="Total exp" name="lname"  value={mentorDetails.total_exp}  />
                              </Form.Group>
                            </div>
                          </div> 
                          <div class="row">
                            <div class="col">
                                <Button variant="primary" type="submit">
                                Submit
                                </Button>
                            </div>
                          </div>  
                        </Form>
                      </ListGroup.Item>
                    </ListGroup>
                   
                    </Card.Text>
                  </Card.Body>
                </Card>
              </div>
            </div>
        </div>
        </div>
              
            )

}
export default MentorProfilePage;